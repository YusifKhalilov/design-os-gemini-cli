# Milestone 02: Audio Core

## Overview
Audio input panel with source selection, spectrum analyzer, and gain control.

---

## Preamble

### What You're Receiving:
- `AudioCore.svelte` component with complete UI
- TypeScript types for AudioSource and AnalysisMetrics
- Sample data for testing

### What You Need to Build:
- Web Audio API integration for spectrum analysis
- System audio capture (via getDisplayMedia)
- File upload handling
- Real-time audio processing store

### Guidelines:
- Panel should float (glassmorphism) and occupy <50% screen
- Spectrum updates at ~60fps
- Beat detection based on transient amplitude

---

## Files to Reference

- `product-plan/sections/audio-core/README.md` — Full specification
- `product-plan/sections/audio-core/types.ts` — TypeScript types
- `product-plan/sections/audio-core/components/AudioCore.svelte` — UI component
- `product-plan/sections/audio-core/sample-data.json` — Test data
- `product-plan/sections/audio-core/tests.md` — Test writing guide

---

## Key Functionality

1. **Source Selection:** Toggle between File Upload and System Audio Capture
2. **Signal Monitoring:** Real-time spectrum analyzer (5-band) and beat detection
3. **Level Adjustment:** Single gain/sensitivity slider (0-100%)
4. **Transient State:** No persistent settings — resets on session end

---

## TDD: Write These Tests First

```typescript
import { render, screen, fireEvent } from '@testing-library/svelte';
import AudioCore from './AudioCore.svelte';
import { audioSource } from '$lib/stores/audioStore';

describe('AudioCore', () => {
  it('should render the audio input panel', () => {
    render(AudioCore, { props: { activeSource: mockSource } });
    expect(screen.getByText('AUDIO INPUT')).toBeInTheDocument();
  });

  it('should display source type toggle buttons', () => {
    render(AudioCore, { props: { activeSource: mockSource } });
    expect(screen.getByText('File Upload')).toBeInTheDocument();
    expect(screen.getByText('System Audio')).toBeInTheDocument();
  });

  it('should switch source type on toggle click', async () => {
    const onSourceChange = vi.fn();
    render(AudioCore, { props: { activeSource: mockSource, onSourceChange } });

    await fireEvent.click(screen.getByText('System Audio'));
    expect(onSourceChange).toHaveBeenCalledWith('system');
  });

  it('should display spectrum analyzer bars', () => {
    render(AudioCore, { props: { activeSource: mockActiveSource } });
    const bars = screen.getAllByTestId('spectrum-bar');
    expect(bars).toHaveLength(5);
  });

  it('should indicate beat detection', () => {
    const sourceWithBeat = { ...mockSource, analysisMetrics: { ...mockSource.analysisMetrics, isBeat: true } };
    render(AudioCore, { props: { activeSource: sourceWithBeat } });
    expect(screen.getByText('BEAT DETECTED')).toBeInTheDocument();
  });

  it('should show gain percentage', () => {
    const sourceWithGain = { ...mockSource, gain: 0.75 };
    render(AudioCore, { props: { activeSource: sourceWithGain } });
    expect(screen.getByText('75%')).toBeInTheDocument();
  });

  it('should call onGainChange when slider moves', async () => {
    const onGainChange = vi.fn();
    render(AudioCore, { props: { activeSource: mockSource, onGainChange } });

    const slider = screen.getByRole('slider');
    await fireEvent.input(slider, { target: { value: '0.5' } });
    expect(onGainChange).toHaveBeenCalledWith(0.5);
  });

  it('should show file drop zone in file mode', () => {
    const fileSource = { ...mockSource, type: 'file' };
    render(AudioCore, { props: { activeSource: fileSource } });
    expect(screen.getByText(/DROP FILE OR CLICK/)).toBeInTheDocument();
  });

  it('should show error state indicator', () => {
    const errorSource = { ...mockSource, status: 'error' };
    render(AudioCore, { props: { activeSource: errorSource } });
    expect(screen.getByTestId('status-indicator')).toHaveClass('bg-red-500');
  });

  it('should display filename and duration for file mode', () => {
    render(AudioCore, { props: { activeSource: mockFileSource } });
    expect(screen.getByText('test_audio.mp3')).toBeInTheDocument();
    expect(screen.getByText(/45.2s/)).toBeInTheDocument();
  });

  it('should display LIVE for system audio mode', () => {
    const systemSource = { ...mockSource, type: 'system', duration: null };
    render(AudioCore, { props: { activeSource: systemSource } });
    expect(screen.getByText('LIVE')).toBeInTheDocument();
  });
});
```

---

## Component Implementation

See `product-plan/sections/audio-core/components/AudioCore.svelte` for the full Svelte 5 component.

---

## Store Implementation

Create `src/lib/stores/audioStore.ts`:

```typescript
import { writable, derived } from 'svelte/store';
import type { AudioSource, AnalysisMetrics } from '$lib/types/audio';

// Initial state
const initialSource: AudioSource = {
  id: 'default',
  type: 'file',
  status: 'idle',
  gain: 0.8,
  filename: '',
  duration: null,
  currentTime: null,
  analysisMetrics: {
    peaks: [0, 0, 0, 0, 0],
    isBeat: false,
    energyLevel: 0
  }
};

// Create writable store
function createAudioStore() {
  const { subscribe, set, update } = writable<AudioSource>(initialSource);

  let audioContext: AudioContext | null = null;
  let analyser: AnalyserNode | null = null;
  let animationFrame: number | null = null;

  return {
    subscribe,

    setSourceType: (type: 'file' | 'system') => {
      update(s => ({ ...s, type, status: 'idle' }));
    },

    setGain: (gain: number) => {
      update(s => ({ ...s, gain }));
      // Apply to audio node if active
    },

    loadFile: async (file: File) => {
      // Implementation: Load file, decode, create source node
    },

    captureSystem: async () => {
      // Implementation: getDisplayMedia for system audio
    },

    startAnalysis: () => {
      // Implementation: Start animation loop for spectrum
    },

    stopAnalysis: () => {
      if (animationFrame) cancelAnimationFrame(animationFrame);
    },

    reset: () => set(initialSource)
  };
}

export const audioStore = createAudioStore();
```

---

## Callback Props

| Prop | Type | Description |
|------|------|-------------|
| `activeSource` | `AudioSource` | Current source configuration |
| `onSourceChange` | `(type: 'file' \| 'system') => void` | Handle source toggle |
| `onFileSelect` | `(file: File) => void` | Handle file input |
| `onGainChange` | `(value: number) => void` | Handle gain slider |
| `onToggleStatus` | `() => void` | Toggle play/pause |

---

## Empty States

| State | Display |
|-------|---------|
| No file selected | "DROP FILE OR CLICK TO BROWSE" with dashed border |
| System audio error | Red status indicator, error message |
| No signal | Flat spectrum bars (all at minimum height) |
| Idle | "SIGNAL ACTIVE" text, dim indicator |

---

## Done Criteria

- [ ] Source toggle switches between File and System modes
- [ ] File drag-and-drop works, shows filename
- [ ] Spectrum bars animate with audio input
- [ ] Beat indicator pulses on detected beats
- [ ] Gain slider adjusts and displays percentage
- [ ] Error states display correctly
- [ ] All tests pass

---

## Next Milestone

Proceed to `03-visual-engine.md` to implement the Visual Engine section.
