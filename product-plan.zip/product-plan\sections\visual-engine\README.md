# Visual Engine Section

Fullscreen generative canvas with audio-reactive visuals and user feedback.

## Overview

The Visual Engine is a hybrid generative system combining geometric 3D forms and organic particle systems. It uses an AI feedback loop where users "teach" the engine their preferences via keyboard shortcuts.

## User Flows

1. **Training Session:** Enter engine → Visuals react to audio → Rate current state → Engine evolves
2. **Like Response:** Ctrl+Shift+Up → +1 particles appear, current traits extended
3. **Dislike Response:** Ctrl+Shift+Down → -1 particles appear, new generation path

## UI Requirements

- **Viewport:** Fullscreen canvas (standalone, no shell chrome)
- **Feedback:** Floating +1/-1 particle emitters
- **HUD:** Session info, keyboard hints (fade on idle)
- **Cursor:** Hidden during visualization

## Props

| Prop | Type | Required | Description |
|------|------|----------|-------------|
| `currentState` | `VisualState` | Yes | Active visual configuration |
| `history` | `VisualState[]` | Yes | Past states for session |
| `onLike` | `function` | Yes | Called on Ctrl+Shift+Up |
| `onDislike` | `function` | Yes | Called on Ctrl+Shift+Down |

## Color Palettes

| Palette | Primary Color |
|---------|---------------|
| cyber-neon | Emerald |
| deep-ocean | Cyan |
| magma | Amber |
| monochrome-glitch | White |
