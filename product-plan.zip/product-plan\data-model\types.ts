// =============================================================================
// Audio Core Types
// =============================================================================

export interface AnalysisMetrics {
  /** Normalized peak values for frequency, typically 5 bands [Low...High] */
  peaks: number[];
  /** Whether a beat is currently detected */
  isBeat: boolean;
  /** Overall energy level of the signal (0.0 - 1.0) */
  energyLevel: number;
}

export interface AudioSource {
  id: string;
  /** The type of input source */
  type: 'file' | 'system';
  /** Current operational status of the source */
  status: 'idle' | 'active' | 'error';
  /** Input gain level (0.0 - 1.0) */
  gain: number;
  /** Name of the file or "System Audio" label */
  filename: string;
  /** Total duration in seconds (null for system audio) */
  duration?: number | null;
  /** Current playback position in seconds (null for system audio) */
  currentTime?: number | null;
  /** Real-time analysis snapshot */
  analysisMetrics: AnalysisMetrics;
}

// =============================================================================
// Visual Engine Types
// =============================================================================

export interface AudioContext {
  bassLevel: number;
  midLevel: number;
  trebleLevel: number;
  tempo: number;
}

export interface VisualState {
  id: string;
  timestamp: string;
  geometryStyle: 'cubic-lattice' | 'spherical-swarm' | 'architectural-lines' | 'organic-mesh';
  palette: 'cyber-neon' | 'deep-ocean' | 'magma' | 'monochrome-glitch';
  particleCount: number;
  particleSpeed: number;
  rating: 1 | -1 | null;
  audioContext: AudioContext;
}

// =============================================================================
// Neural Link Types
// =============================================================================

export interface ModelConfig {
  id: string;
  name: string;
  architecture: 'Dense' | 'CNN' | 'RNN' | 'Custom';
  learningRate: number;
  batchSize: number;
  epochs: number;
  optimizer: 'adam' | 'sgd' | 'rmsprop';
  description: string;
}

export interface Dataset {
  id: string;
  name: string;
  sampleCount: number;
  features: string[];
  created: string;
}

export interface MetricPoint {
  epoch: number;
  loss: number;
  accuracy: number;
}

export interface TrainingSession {
  id: string;
  configId: string;
  datasetId: string;
  status: 'idle' | 'training' | 'paused' | 'completed' | 'stopped';
  currentEpoch: number;
  totalEpochs: number;
  startTime: string;
  loss: number;
  accuracy: number;
  metricsHistory: MetricPoint[];
}

// =============================================================================
// Vector Shell Types
// =============================================================================

export interface ShellState {
  isPlaying: boolean;
  activeOverlay: 'audio' | 'visual' | 'neural' | null;
  currentPresetId: string;
}

export interface SystemSettings {
  themeMode: 'dark' | 'light' | 'system';
  performanceMode: 'saver' | 'balanced' | 'high-performance';
  audioDeviceId: string;
  showFps: boolean;
}

export interface ScenePreset {
  id: string;
  name: string;
  category: string;
  hotkey: string;
}

// =============================================================================
// Component Props
// =============================================================================

export interface AudioCoreProps {
  activeSource: AudioSource;
  onSourceChange?: (type: 'file' | 'system') => void;
  onFileSelect?: (file: File) => void;
  onGainChange?: (value: number) => void;
  onToggleStatus?: () => void;
}

export interface VisualEngineProps {
  history: VisualState[];
  currentState: VisualState;
  onLike: () => void;
  onDislike: () => void;
}

export interface NeuralLinkProps {
  modelConfigs: ModelConfig[];
  datasets: Dataset[];
  sessions: TrainingSession[];
  onStartTraining: (configId: string, datasetId: string) => void;
  onPauseTraining: (sessionId: string) => void;
  onResumeTraining: (sessionId: string) => void;
  onStopTraining: (sessionId: string) => void;
  onUpdateConfig: (configId: string, updates: Partial<ModelConfig>) => void;
  onCreateConfig: (config: Omit<ModelConfig, 'id'>) => void;
}

export interface VectorShellProps {
  shellState: ShellState;
  settings: SystemSettings;
  presets: ScenePreset[];
  onTogglePlayback?: () => void;
  onOpenOverlay?: (overlay: 'audio' | 'visual' | 'neural' | null) => void;
  onApplyPreset?: (presetId: string) => void;
  onUpdateSettings?: (key: keyof SystemSettings, value: any) => void;
}
