# VectorHive - One-Shot Implementation Prompt

Use this prompt with your coding agent to implement the entire application in one session.

---

## Prompt

```
I need you to implement VectorHive, a personal music visualization application.

## Files to Read First

Please read these files in order before asking questions:

1. `product-plan/product-overview.md` — Complete product context
2. `product-plan/instructions/one-shot-instructions.md` — All implementation milestones
3. `product-plan/design-system/tokens.css` — CSS custom properties
4. `product-plan/data-model/types.ts` — All TypeScript types

## Before You Start

I need you to ask me clarifying questions about:

1. **Audio Implementation:**
   - Should I implement actual Web Audio API integration, or mock it for now?
   - Do you have a preference for audio analysis library (e.g., Meyda, custom FFT)?

2. **Graphics Engine:**
   - Should I use Three.js, raw WebGL, or a lighter 2D canvas approach?
   - What level of visual complexity is acceptable for initial version?

3. **ML Integration:**
   - Should I implement actual TensorFlow.js training, or mock the ML functionality?
   - What model architecture should I start with?

4. **State Management:**
   - Should I use Svelte stores, or a specific state management pattern?
   - How should I persist user preferences (localStorage, IndexedDB)?

5. **Testing:**
   - Which test framework should I use (Vitest, Playwright, both)?
   - Should I write tests before or after implementation?

## Tech Stack

- Svelte 5 (Runes mode with $state, $derived, $effect)
- Vite
- Tailwind CSS
- TypeScript

## Additional Notes

[ADD YOUR SPECIFIC REQUIREMENTS HERE]

```

---

## After the Agent Responds

1. Answer all clarifying questions
2. Let the agent read the instruction files
3. Review the implementation plan it proposes
4. Approve or adjust before it starts coding

## Tips

- The agent will ask good questions — answer them thoughtfully
- Break implementation into commits if possible
- Test each milestone before moving to the next
