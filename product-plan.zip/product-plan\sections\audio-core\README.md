# Audio Core Section

Audio input panel with source selection, spectrum analyzer, and gain control.

## Overview

The Audio Core module functions as the reliable input stage for the system, handling both file playback and internal system audio capture. It features a compact, reliable interface for signal monitoring and basic gain staging.

## User Flows

1. **Source Selection:** Toggle between "File Mode" (drag & drop) and "System Capture" (internal audio loopback)
2. **Signal Monitoring:** Real-time spectrum analyzer and beat detection indicators
3. **Level Adjustment:** Single gain/sensitivity slider

## UI Requirements

- **Floating Glass Layout:** Panel dynamically resizes but occupies <50% screen estate
- **Visualizers:** Integrated spectrum analyzer (5-band) and beat pulse indicator
- **Input Controls:** Toggle for source and slider for gain
- **Transient State:** Controls reset on session end

## Components

- `AudioCore.svelte` — Main panel component with all controls

## Props

| Prop | Type | Required | Description |
|------|------|----------|-------------|
| `activeSource` | `AudioSource` | Yes | Current audio configuration |
| `onSourceChange` | `function` | No | Called when source type changes |
| `onFileSelect` | `function` | No | Called when file is selected |
| `onGainChange` | `function` | No | Called when gain slider changes |
| `onToggleStatus` | `function` | No | Called to toggle play/pause |

## Visual Reference

See `audio-core-preview.png` if available.
