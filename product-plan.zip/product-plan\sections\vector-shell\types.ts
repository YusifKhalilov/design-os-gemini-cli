// =============================================================================
// Data Types
// =============================================================================

export interface ShellState {
  isPlaying: boolean
  activeOverlay: 'audio' | 'visual' | 'neural' | null
  currentPresetId: string
}

export interface SystemSettings {
  themeMode: 'dark' | 'light' | 'system'
  performanceMode: 'saver' | 'balanced' | 'high-performance'
  audioDeviceId: string
  showFps: boolean
}

export interface ScenePreset {
  id: string
  name: string
  category: string
  hotkey: string
}

// =============================================================================
// Component Props
// =============================================================================

export interface VectorShellProps {
  /** Current state of the shell (playback, overlays) */
  shellState: ShellState
  /** Global system settings */
  settings: SystemSettings
  /** List of available scene presets */
  presets: ScenePreset[]

  /** Called when user toggles play/pause */
  onTogglePlayback?: () => void
  /** Called when user opens a specific overlay (Audio, Visual, Neural) */
  onOpenOverlay?: (overlay: 'audio' | 'visual' | 'neural' | null) => void
  /** Called when user selects a preset scene */
  onApplyPreset?: (presetId: string) => void
  /** Called when user updates a system setting */
  onUpdateSettings?: (key: keyof SystemSettings, value: any) => void
}
