# Typography Setup

## Google Fonts Import

Add to your `index.html` or `app.html`:

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;700&family=Manrope:wght@400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
```

## Font Families

| Usage | Font | Weights |
|-------|------|---------|
| **Headings** | Space Grotesk | 400, 500, 600, 700 |
| **Body/UI** | Manrope | 400, 500, 600, 700 |
| **Monospace** | JetBrains Mono | 400, 500, 700 |

## Tailwind Configuration

```javascript
// tailwind.config.js
export default {
  theme: {
    extend: {
      fontFamily: {
        heading: ['Space Grotesk', 'sans-serif'],
        body: ['Manrope', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace']
      }
    }
  }
}
```

## CSS Custom Properties

```css
:root {
  --font-heading: 'Space Grotesk', sans-serif;
  --font-body: 'Manrope', sans-serif;
  --font-mono: 'JetBrains Mono', monospace;
}
```

## Usage Examples

```html
<h1 class="font-heading text-4xl font-bold">Heading</h1>
<p class="font-body text-base">Body text</p>
<code class="font-mono text-sm">const code = true;</code>
```
