# VectorHive - Product Overview

## Summary

VectorHive is a personal, high-intensity music visualization tool that generates immersive geometric patterns fueled by music. It extracts complex sound features to dynamically control shapes, speed, particles, textures, and colors, creating a unique visual journey for every track.

## Problems Solved

1. **Static Visuals** — Most visualizers use pre-baked loops. VectorHive uses real-time audio feature extraction to drive every visual variable.

2. **Audio Source Limitations** — Difficult to visualize external audio in browsers. VectorHive supports internal system output capture and direct file uploads.

3. **Usage Friction** — Many tools require accounts. VectorHive is zero-auth, completely local.

4. **Lack of Adaptation** — Most visualizers are random or deterministic. VectorHive uses TensorFlow.js learning with user feedback (Shift+Ctrl+Up/Down).

## Key Features

- **Dual Audio Input:** System audio capture & file upload
- **Deep Audio Reactivity:** Extracts audio data to drive geometry, particles, colors
- **AI Learning Loop:** TensorFlow.js model trains on +1/-1 user ratings
- **Dynamic Visuals:** Wide spectrum of colors and mathematical forms
- **Private & Local:** No accounts, no database, no tracking

---

## Sections (in implementation order)

### 1. Audio Core
Manages audio input sources (file/system) and real-time feature extraction.

**Key Functionality:**
- Source selection (File Mode vs System Capture)
- Real-time spectrum analyzer and beat detection
- Input gain/sensitivity slider
- Floating glassmorphic panel (<50% screen)

**Configuration:** Shell-integrated (appears as overlay panel)

---

### 2. Visual Engine
Generates dynamic geometric patterns and particles driven by audio data.

**Key Functionality:**
- Fullscreen canvas (standalone, no shell chrome)
- Geometry layer synced to audio beats
- Particle layer influenced by audio mood
- User training via Ctrl+Shift+Up (Like) and Ctrl+Shift+Down (Dislike)
- Playful +1/-1 particle feedback

**Configuration:** Standalone fullscreen (shell: false)

---

### 3. Neural Link
Handles the TensorFlow.js model and user training feedback loop.

**Key Functionality:**
- Model configuration (architecture, hyperparameters)
- Training lifecycle (start/pause/resume/stop)
- Real-time loss/accuracy visualization
- Dataset management
- Status indicators and toast notifications

**Configuration:** Shell-integrated (appears as overlay panel)

---

### 4. Vector Shell
The primary interface container and overlay controls.

**Key Functionality:**
- HUD overlay floating above WebGL canvas
- Persistent Utility Dock (transport, modules, presets, system)
- Full-screen overlays for deep configuration
- Desktop/Tablet optimized (dense information density)

**Configuration:** This IS the shell wrapper

---

## Data Model Entities

### AudioSource
Configuration for active audio input (file or system capture).

**Fields:**
- `id`: string
- `type`: 'file' | 'system'
- `status`: 'idle' | 'active' | 'error'
- `gain`: number (0.0-1.0)
- `filename`: string
- `duration`: number | null
- `currentTime`: number | null
- `analysisMetrics`: AnalysisMetrics

### TrainingEvent
Snapshot captured when user provides feedback.

**Fields:**
- Audio features (bass, energy, mid-range intensity)
- Visual state (geometry style, color palette, particle speed)
- User rating (+1 or -1)

### VisualState
Snapshot of generative visual parameters.

**Fields:**
- `id`: string
- `geometryStyle`: 'cubic-lattice' | 'spherical-swarm' | 'architectural-lines' | 'organic-mesh'
- `palette`: 'cyber-neon' | 'deep-ocean' | 'magma' | 'monochrome-glitch'
- `particleCount`: number
- `particleSpeed`: number
- `rating`: 1 | -1 | null

### ModelConfig
Neural network configuration preset.

**Fields:**
- `id`: string
- `name`: string
- `architecture`: 'Dense' | 'CNN' | 'RNN' | 'Custom'
- `learningRate`: number
- `batchSize`: number
- `epochs`: number
- `optimizer`: 'adam' | 'sgd' | 'rmsprop'

### TrainingSession
Training run record with metrics.

**Fields:**
- `id`: string
- `status`: 'idle' | 'training' | 'paused' | 'completed' | 'stopped'
- `currentEpoch`: number
- `loss`: number
- `accuracy`: number
- `metricsHistory`: MetricPoint[]

---

## Design System

### Colors (Tailwind Palette)
- **Primary:** Emerald (emerald-500, emerald-400, etc.)
- **Secondary:** Violet (violet-500, violet-400, etc.)
- **Neutral:** Zinc (zinc-950, zinc-900, zinc-800, etc.)

### Typography (Google Fonts)
- **Headings:** Space Grotesk
- **Body/UI:** Manrope
- **Monospace:** JetBrains Mono

### Visual Style
- Glassmorphism (backdrop-blur, low opacity backgrounds)
- Dark mode primary
- Neon glow effects (box-shadow with color)
- HUD/tech aesthetic

---

## Implementation Milestones

| # | Milestone | Description |
|---|-----------|-------------|
| 1 | Foundation | Design tokens, routing, shell setup |
| 2 | Audio Core | Audio input panel with spectrum analyzer |
| 3 | Visual Engine | Fullscreen generative visuals |
| 4 | Neural Link | ML training dashboard |
| 5 | Vector Shell | HUD overlay and utility dock |

---

## Target Stack

- **Framework:** Svelte 5 (Runes mode)
- **Styling:** Tailwind CSS
- **Build:** Vite
- **ML:** TensorFlow.js
- **Audio:** Web Audio API
- **Graphics:** WebGL / Three.js (or similar)
