# Neural Link Section

TensorFlow.js model training dashboard with real-time metrics visualization.

## Overview

The Neural Link interface serves as the command center for the machine learning backend. Users can configure models, manage training sessions, and visualize learning progress in real-time.

## User Flows

1. **Model Configuration:** Select architecture, adjust hyperparameters
2. **Training Lifecycle:** Start, pause, resume, stop training
3. **Performance Monitoring:** Watch loss/accuracy charts update in real-time
4. **Data Ingestion:** Select datasets for training

## UI Requirements

- **Control Panel:** Hyperparameter sliders and inputs
- **Visualization Dashboard:** Real-time line charts for metrics
- **Training Controls:** Prominent Play/Pause/Stop buttons
- **Status Indicators:** Epoch count, elapsed time, tensor status
- **Toast Notifications:** "Training Complete", "Convergence Reached"

## Components

- `NeuralLinkDashboard.svelte` — Main dashboard
- `ControlPanel.svelte` — Hyperparameter controls
- `TrainingControls.svelte` — Start/Pause/Stop buttons
- `VisualizationDashboard.svelte` — Metrics chart
- `MetricCard.svelte` — Individual metric display

## Props (NeuralLinkDashboard)

| Prop | Type | Description |
|------|------|-------------|
| `modelConfigs` | `ModelConfig[]` | Available configurations |
| `datasets` | `Dataset[]` | Training datasets |
| `sessions` | `TrainingSession[]` | All sessions |
| `onStartTraining` | `function` | Start new session |
| `onPauseTraining` | `function` | Pause session |
| `onResumeTraining` | `function` | Resume session |
| `onStopTraining` | `function` | Stop session |
| `onUpdateConfig` | `function` | Edit configuration |
