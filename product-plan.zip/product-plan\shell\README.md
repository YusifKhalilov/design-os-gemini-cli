# Shell Components

Application shell components for VectorHive's immersive interface.

## Components

- `AppShell.svelte` — Main layout wrapper with dynamic background
- `MainNav.svelte` — Floating dock navigation
- `UserMenu.svelte` — User dropdown (optional for local app)

## Layout Pattern

**Immersive / Floating Dock**
- Background: Full-screen Visual Engine canvas (always active)
- Navigation: Centered floating glassmorphic dock at bottom
- Panels: Secondary sections open as translucent overlays

## Design Tokens

- **Colors:** Emerald (Primary), Violet (Secondary), Zinc (Neutral)
- **Typography:** Space Grotesk (Headings), Manrope (UI)
- **Effects:** Glassmorphism, backdrop-blur, neon glow
