# Neural Link Tests

Test instructions for the Neural Link section.

## Unit Tests

### Model Selection
- [ ] Displays all model configurations
- [ ] Highlights selected config
- [ ] Shows architecture and optimizer info

### Hyperparameter Controls
- [ ] Learning rate slider works
- [ ] Batch size buttons work
- [ ] Epochs input works
- [ ] Optimizer toggle works
- [ ] Controls disabled during training

### Training Controls
- [ ] Start button visible when idle
- [ ] Pause button visible when training
- [ ] Resume button visible when paused
- [ ] Stop button visible when active
- [ ] Correct callbacks are fired

### Metrics Display
- [ ] Current loss displays correctly
- [ ] Accuracy displays as percentage
- [ ] Epoch count shows progress
- [ ] Estimated time updates

### Chart Visualization
- [ ] Chart renders with data
- [ ] Accuracy line is emerald
- [ ] Loss line is violet
- [ ] Grid background displays
- [ ] Active dot animates during training

### Empty States
- [ ] "WAITING FOR SIGNAL" when no data
- [ ] "No Configuration Selected" message

## Integration Tests

### Training Loop
- [ ] Training starts on button click
- [ ] Metrics update during training
- [ ] Training can be paused
- [ ] Training can be resumed
- [ ] Training can be stopped
- [ ] Config locked during training
