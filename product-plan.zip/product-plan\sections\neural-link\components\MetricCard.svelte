<script lang="ts">
  interface Props {
    label: string;
    value: string | number;
    subValue?: string;
    trend?: 'up' | 'down' | 'neutral';
    color?: 'emerald' | 'violet' | 'amber' | 'blue';
  }

  let { label, value, subValue, trend, color = 'emerald' }: Props = $props();

  const colorStyles = {
    emerald: 'text-primary-400 border-primary-500/20 bg-primary-500/5',
    violet: 'text-secondary-400 border-secondary-500/20 bg-secondary-500/5',
    amber: 'text-amber-400 border-amber-500/20 bg-amber-500/5',
    blue: 'text-blue-400 border-blue-500/20 bg-blue-500/5',
  };
</script>

<div class="relative overflow-hidden rounded-xl border p-4 {colorStyles[color]} backdrop-blur-sm">
  <div class="relative z-10">
    <div class="grid grid-cols-2 justify-between items-start mb-2">
      <span class="text-[10px] font-mono uppercase tracking-widest opacity-70">{label}</span>
      {#if trend}
        <span class="text-xs text-right" class:rotate-180={trend === 'down'}>
          {trend === 'neutral' ? '•' : '↑'}
        </span>
      {/if}
    </div>
    <div class="text-2xl font-bold font-mono tracking-tight">{value}</div>
    {#if subValue}
      <div class="mt-1 text-xs opacity-60 font-mono">{subValue}</div>
    {/if}
  </div>

  <!-- Background glow -->
  <div class="absolute -right-6 -bottom-6 w-20 h-20 rounded-full blur-2xl opacity-20 bg-current"></div>
</div>
