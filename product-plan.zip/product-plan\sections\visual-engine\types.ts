// =============================================================================
// Data Types
// =============================================================================

export interface AudioContext {
  bassLevel: number
  midLevel: number
  trebleLevel: number
  tempo: number
}

export interface VisualState {
  id: string
  timestamp: string
  geometryStyle: 'cubic-lattice' | 'spherical-swarm' | 'architectural-lines' | 'organic-mesh'
  palette: 'cyber-neon' | 'deep-ocean' | 'magma' | 'monochrome-glitch'
  particleCount: number
  particleSpeed: number
  rating: 1 | -1 | null
  audioContext: AudioContext
}

// =============================================================================
// Component Props
// =============================================================================

export interface VisualEngineProps {
  /** The sequence of visual states generated in the current session */
  history: VisualState[]
  /** The currently active visual state being rendered */
  currentState: VisualState
  /** Called when the user likes the current state (Ctrl+Shift+Up) */
  onLike: () => void
  /** Called when the user dislikes the current state (Ctrl+Shift+Down) */
  onDislike: () => void
}
