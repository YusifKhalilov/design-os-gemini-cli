# Vector Shell Tests

Test instructions for the Vector Shell section.

## Unit Tests

### Utility Dock
- [ ] Dock renders at bottom center
- [ ] All button groups display
- [ ] Dock has glassmorphic styling

### Transport Controls
- [ ] Play button shows when not playing
- [ ] Pause button shows when playing
- [ ] Button toggles playback state
- [ ] Reset button displays

### Module Buttons
- [ ] Audio Core button displays
- [ ] Visual Engine button displays
- [ ] Neural Link button displays
- [ ] Active module is highlighted
- [ ] Clicking opens overlay

### Preset Switcher
- [ ] All 5 preset buttons display
- [ ] Current preset is highlighted
- [ ] Clicking applies preset
- [ ] Hotkey numbers show

### System Controls
- [ ] Mic button displays
- [ ] Performance mode toggle works
- [ ] Settings button displays

### Overlay System
- [ ] Overlay opens on module click
- [ ] Overlay displays correct header
- [ ] Close button closes overlay
- [ ] Backdrop blur is present

### Status Bar
- [ ] Current preset name displays
- [ ] FPS counter shows
- [ ] DSP status indicator shows

## Integration Tests

### State Management
- [ ] Playback state persists
- [ ] Preset changes update visuals
- [ ] Settings persist to localStorage
- [ ] Overlay state tracks correctly
