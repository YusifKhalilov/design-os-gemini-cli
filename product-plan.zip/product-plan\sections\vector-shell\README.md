# Vector Shell Section

HUD overlay container with utility dock and deep configuration overlays.

## Overview

The Vector Shell serves as the primary immersive container, wrapping all modules. It uses a HUD aesthetic where UI controls float over the full-screen visual canvas, optimized for Desktop and Tablet.

## User Flows

1. **Primary Visualization:** Full-screen output with minimal UI interference
2. **Quick Control:** Persistent Utility Dock for playback, inputs, presets
3. **Deep Configuration:** Full-screen overlays for Audio/Neural/Visual settings

## UI Requirements

- **HUD Overlay:** Glassmorphic elements float above WebGL canvas
- **Utility Dock:** Fixed bottom dock with transport, modules, presets, system
- **Full-Screen Overlays:** Deep configuration views
- **Desktop/Tablet:** Dense information density allowed

## Components

- `VectorShell.svelte` — Main HUD container
- `UtilityDock.svelte` — Bottom dock component

## Props (VectorShell)

| Prop | Type | Description |
|------|------|-------------|
| `shellState` | `ShellState` | Playback and overlay state |
| `settings` | `SystemSettings` | Global settings |
| `presets` | `ScenePreset[]` | Scene presets |
| `onTogglePlayback` | `function` | Toggle play/pause |
| `onOpenOverlay` | `function` | Open module config |
| `onApplyPreset` | `function` | Switch preset |
| `onUpdateSettings` | `function` | Update setting |

## Dock Groups

1. **Transport:** Reset, Play/Pause
2. **Modules:** Audio, Visual, Neural
3. **Presets:** 1-5 quick-switch buttons
4. **System:** Mic, Performance, Settings
