<script lang="ts">
  import type { NeuralLinkProps, ModelConfig } from '../types';
  import VisualizationDashboard from './VisualizationDashboard.svelte';
  import ControlPanel from './ControlPanel.svelte';
  import TrainingControls from './TrainingControls.svelte';
  import MetricCard from './MetricCard.svelte';

  let {
    modelConfigs,
    datasets,
    sessions,
    onStartTraining,
    onPauseTraining,
    onResumeTraining,
    onStopTraining,
    onUpdateConfig,
  }: NeuralLinkProps = $props();

  let selectedConfigId = $state(modelConfigs[0]?.id);
  let selectedConfig = $derived(modelConfigs.find(c => c.id === selectedConfigId));
  let activeSession = $derived(sessions.find(s => ['training', 'paused'].includes(s.status)));
  let displaySession = $derived(activeSession || sessions[0]);

  function handleStart() {
    if (selectedConfigId && datasets[0]) {
      onStartTraining(selectedConfigId, datasets[0].id);
    }
  }
</script>

<div class="w-full h-full min-h-screen bg-black text-zinc-100 font-body selection:bg-primary-500/30">
  <!-- Top Bar -->
  <header class="h-16 border-b border-zinc-800 grid grid-cols-[auto_1fr_auto] gap-4 items-center px-6 bg-zinc-950/50 backdrop-blur sticky top-0 z-50">
    <div class="grid grid-flow-col gap-3 items-center">
      <div class="w-2 h-2 rounded-full bg-primary-500 animate-pulse"></div>
      <h1 class="text-lg font-bold tracking-tight text-white font-heading">NEURAL LINK <span class="text-zinc-600 font-normal">v2.4</span></h1>
    </div>
    <div></div>
    <div class="grid grid-flow-col gap-6 items-center">
      <div class="grid gap-0.5 text-right">
        <span class="text-[10px] text-zinc-500 font-mono uppercase">System Load</span>
        <span class="text-xs font-mono text-primary-400">12% GPU</span>
      </div>
      <div class="w-px h-8 bg-zinc-800"></div>
      <div class="grid gap-0.5 text-right">
        <span class="text-[10px] text-zinc-500 font-mono uppercase">Memory</span>
        <span class="text-xs font-mono text-secondary-400">3.2 GB / 16 GB</span>
      </div>
    </div>
  </header>

  <main class="p-6 grid grid-cols-12 gap-6 h-[calc(100vh-64px)]">
    <!-- Left Sidebar -->
    <div class="col-span-3 grid gap-6 content-start overflow-y-auto pr-2">
      <!-- Model Selector -->
      <div class="space-y-3">
        <label class="text-xs font-mono text-zinc-500 uppercase tracking-widest pl-1">Architecture</label>
        <div class="space-y-2">
          {#each modelConfigs as config}
            <button
              onclick={() => selectedConfigId = config.id}
              class="w-full text-left p-3 rounded-lg border transition-all"
              class:bg-zinc-900={selectedConfigId === config.id}
              class:border-primary-500/50={selectedConfigId === config.id}
              class:shadow-[0_0_15px_rgba(16,185,129,0.1)]={selectedConfigId === config.id}
              class:bg-zinc-950={selectedConfigId !== config.id}
              class:border-zinc-800={selectedConfigId !== config.id}
              class:hover:border-zinc-700={selectedConfigId !== config.id}
              class:hover:bg-zinc-900/50={selectedConfigId !== config.id}
            >
              <div class="grid grid-cols-[1fr_auto] items-center mb-1">
                <span class="text-sm font-medium" class:text-white={selectedConfigId === config.id} class:text-zinc-400={selectedConfigId !== config.id}>
                  {config.name}
                </span>
                {#if selectedConfigId === config.id}
                  <div class="w-1.5 h-1.5 rounded-full bg-primary-500"></div>
                {/if}
              </div>
              <div class="text-[10px] text-zinc-500 font-mono truncate">{config.architecture} • {config.optimizer}</div>
            </button>
          {/each}
        </div>
      </div>

      <ControlPanel
        config={selectedConfig}
        onUpdate={(updates) => selectedConfigId && onUpdateConfig(selectedConfigId, updates)}
        readOnly={!!activeSession}
      />

      <!-- Dataset Selector -->
      <div class="space-y-3">
        <label class="text-xs font-mono text-zinc-500 uppercase tracking-widest pl-1">Dataset Source</label>
        <div class="p-3 rounded-lg border border-zinc-800 bg-zinc-950/50 grid grid-cols-[1fr_auto] items-center group cursor-pointer hover:border-zinc-700 transition-colors">
          <div class="grid gap-0.5">
            <span class="text-sm text-zinc-300 group-hover:text-white transition-colors">{datasets[0]?.name || 'No dataset'}</span>
            <span class="text-[10px] text-zinc-500 font-mono">{datasets[0]?.sampleCount || 0} Samples</span>
          </div>
          <span class="text-zinc-600 text-[10px] font-mono border border-zinc-800 px-1.5 py-0.5 rounded">ACTIVE</span>
        </div>
      </div>
    </div>

    <!-- Center - Visualization -->
    <div class="col-span-9 grid gap-6 content-start">
      <!-- Metrics Row -->
      <div class="grid grid-cols-4 gap-4">
        <MetricCard
          label="Current Loss"
          value={displaySession?.loss.toFixed(4) ?? '---'}
          color="violet"
          trend="down"
        />
        <MetricCard
          label="Accuracy"
          value={displaySession ? `${(displaySession.accuracy * 100).toFixed(1)}%` : '---'}
          color="emerald"
          trend="up"
        />
        <MetricCard
          label="Epoch"
          value={displaySession ? `${displaySession.currentEpoch} / ${displaySession.totalEpochs}` : '---'}
          subValue={displaySession?.status === 'training' ? 'Running...' : 'Done'}
          color="blue"
        />
        <MetricCard
          label="Est. Time"
          value="04:20"
          subValue="Remaining"
          color="amber"
        />
      </div>

      <!-- Main Graph -->
      <div class="flex-1 min-h-[400px] relative">
        <VisualizationDashboard
          metrics={displaySession?.metricsHistory ?? []}
          status={displaySession?.status ?? 'idle'}
        />

        <!-- Floating Controls -->
        <div class="absolute bottom-8 left-1/2 -translate-x-1/2">
          <TrainingControls
            status={activeSession?.status ?? 'idle'}
            onStart={handleStart}
            onPause={() => activeSession && onPauseTraining(activeSession.id)}
            onResume={() => activeSession && onResumeTraining(activeSession.id)}
            onStop={() => activeSession && onStopTraining(activeSession.id)}
          />
        </div>
      </div>
    </div>
  </main>
</div>
