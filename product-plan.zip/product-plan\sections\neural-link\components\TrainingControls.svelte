<script lang="ts">
  interface Props {
    status: 'idle' | 'training' | 'paused' | 'completed' | 'stopped';
    onStart: () => void;
    onPause: () => void;
    onResume: () => void;
    onStop: () => void;
  }

  let { status, onStart, onPause, onResume, onStop }: Props = $props();

  let isTraining = $derived(status === 'training');
  let isPaused = $derived(status === 'paused');
  let canStart = $derived(status === 'idle' || status === 'completed' || status === 'stopped');
</script>

<div class="grid grid-flow-col gap-4 items-center bg-zinc-900/80 backdrop-blur border border-zinc-800 p-2 pr-4 rounded-full shadow-lg shadow-black/20">

  <!-- Primary Action Button -->
  {#if canStart}
    <button
      onclick={onStart}
      class="group relative grid place-items-center w-12 h-12 rounded-full bg-primary-500 hover:bg-primary-400 text-black transition-all shadow-[0_0_20px_rgba(16,185,129,0.3)] hover:shadow-[0_0_30px_rgba(16,185,129,0.5)] active:scale-95"
      aria-label="Start training"
    >
      <svg class="w-5 h-5 fill-current ml-0.5" viewBox="0 0 24 24">
        <path d="M8 5v14l11-7z" />
      </svg>
    </button>
  {/if}

  {#if isTraining}
    <button
      onclick={onPause}
      class="group relative grid place-items-center w-12 h-12 rounded-full bg-amber-500 hover:bg-amber-400 text-black transition-all shadow-[0_0_20px_rgba(245,158,11,0.3)] hover:shadow-[0_0_30px_rgba(245,158,11,0.5)] active:scale-95"
      aria-label="Pause training"
    >
      <svg class="w-5 h-5 fill-current" viewBox="0 0 24 24">
        <path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" />
      </svg>
    </button>
  {/if}

  {#if isPaused}
    <button
      onclick={onResume}
      class="group relative grid place-items-center w-12 h-12 rounded-full bg-primary-500 hover:bg-primary-400 text-black transition-all shadow-[0_0_20px_rgba(16,185,129,0.3)] hover:shadow-[0_0_30px_rgba(16,185,129,0.5)] active:scale-95"
      aria-label="Resume training"
    >
      <svg class="w-5 h-5 fill-current ml-0.5" viewBox="0 0 24 24">
        <path d="M8 5v14l11-7z" />
      </svg>
    </button>
  {/if}

  <!-- Stop Button -->
  {#if !canStart}
    <button
      onclick={onStop}
      class="grid place-items-center w-10 h-10 rounded-full bg-zinc-800 hover:bg-red-500/20 hover:text-red-500 text-zinc-400 border border-zinc-700 hover:border-red-500/50 transition-all active:scale-95"
      aria-label="Stop training"
    >
      <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24">
        <path d="M6 6h12v12H6z" />
      </svg>
    </button>
  {/if}

  <!-- Status Text -->
  <div class="grid gap-0.5">
    <span class="text-[10px] text-zinc-500 font-mono uppercase tracking-widest leading-none">Status</span>
    <span
      class="text-xs font-bold uppercase tracking-wider animate-pulse"
      class:text-primary-400={status === 'training'}
      class:text-amber-400={status === 'paused'}
      class:text-zinc-400={status === 'idle'}
      class:text-zinc-300={status === 'completed' || status === 'stopped'}
    >
      {status === 'training' ? 'Training Loop Active' : status}
    </span>
  </div>
</div>
