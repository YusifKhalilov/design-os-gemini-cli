<script lang="ts">
  import type { VectorShellProps } from '../types';
  import UtilityDock from './UtilityDock.svelte';
  import { X, Waves, Hexagon, Network } from 'lucide-svelte';

  let {
    shellState,
    settings,
    presets,
    onTogglePlayback,
    onOpenOverlay,
    onApplyPreset,
    onUpdateSettings,
  }: VectorShellProps = $props();

  let currentPreset = $derived(presets.find(p => p.id === shellState.currentPresetId));
</script>

<div id="vs-root" class="relative w-full h-screen bg-black text-zinc-100 overflow-hidden selection:bg-primary-500/30">
  <!-- Canvas Layer - Visual Engine Placeholder -->
  <div id="vs-canvas-layer" class="absolute inset-0 z-0">
    <div id="vs-bg-gradient" class="absolute inset-0" style="background: radial-gradient(ellipse at 50% 50%, #0a0a0a 0%, #000 70%)"></div>

    <!-- Animated Orbs -->
    <div id="vs-orbs" class="absolute inset-0 transition-opacity duration-1000" class:opacity-100={shellState.isPlaying} class:opacity-20={!shellState.isPlaying}>
      <div class="absolute top-1/4 left-1/3 w-[400px] h-[400px] rounded-full blur-[100px] animate-pulse" style="background: radial-gradient(circle, rgba(16,185,129,0.15) 0%, transparent 70%)"></div>
      <div class="absolute bottom-1/3 right-1/4 w-[500px] h-[500px] rounded-full blur-[120px] animate-pulse" style="background: radial-gradient(circle, rgba(139,92,246,0.1) 0%, transparent 70%); animation-delay: 1s"></div>
    </div>

    <!-- Grid Overlay -->
    <div id="vs-grid" class="absolute inset-0 opacity-[0.03]" style="background-image: linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px); background-size: 60px 60px;"></div>

    <!-- Center Visual -->
    <div id="vs-center-visual" class="absolute inset-0 grid place-items-center transition-all duration-700" class:scale-100={shellState.isPlaying} class:opacity-100={shellState.isPlaying} class:scale-90={!shellState.isPlaying} class:opacity-30={!shellState.isPlaying}>
      <div id="vs-geometry" class="relative">
        <!-- Rotating Rings -->
        <div class="absolute -inset-32 border border-primary-500/10 rounded-full" style="animation: spin 30s linear infinite;"></div>
        <div class="absolute -inset-24 border border-secondary-500/10 rounded-full" style="animation: spin 20s linear infinite reverse;"></div>
        <div class="absolute -inset-16 border border-white/5 rounded-full" style="animation: spin 15s linear infinite;"></div>

        <!-- Center Content -->
        <div id="vs-title-block" class="text-center space-y-6">
          <div class="space-y-2">
            <h1 class="text-7xl font-black tracking-tighter bg-gradient-to-b from-white via-white to-white/20 bg-clip-text text-transparent uppercase">
              {currentPreset?.name || 'VECTOR'}
            </h1>
            <div class="h-px w-48 mx-auto bg-gradient-to-r from-transparent via-primary-500/50 to-transparent"></div>
          </div>
          <p class="font-mono text-xs tracking-[0.4em] uppercase text-primary-500/80">
            {shellState.isPlaying ? '● ACTIVE' : '○ STANDBY'}
          </p>
        </div>
      </div>
    </div>
  </div>

  <!-- HUD Corners -->
  <div id="vs-hud-tl" class="absolute top-6 left-6 z-20 font-mono text-[10px] text-zinc-700 space-y-1">
    <div class="text-primary-600/60">VECTOR.SHELL</div>
    <div>v2.0.4-α</div>
  </div>

  <div id="vs-hud-tr" class="absolute top-6 right-6 z-20 font-mono text-[10px] text-zinc-700 text-right space-y-1">
    <div>ENV.PRODUCTION</div>
    <div class="text-zinc-800">ID:{settings.audioDeviceId}</div>
  </div>

  <!-- Configuration Overlay -->
  {#if shellState.activeOverlay}
    <div id="vs-overlay-backdrop" class="absolute inset-0 z-40 bg-black/70 backdrop-blur-sm grid place-items-center">
      <div id="vs-overlay-panel" class="w-full max-w-4xl max-h-[70vh] mx-6 bg-zinc-950/95 border border-white/10 rounded-3xl shadow-2xl grid grid-rows-[auto_1fr] overflow-hidden">
        <!-- Overlay Header -->
        <div id="vs-overlay-header" class="grid grid-cols-[auto_1fr_auto] gap-4 items-center p-6 border-b border-white/5">
          <div class="p-3 rounded-xl" class:bg-secondary-500/20={shellState.activeOverlay === 'audio'} class:text-secondary-400={shellState.activeOverlay === 'audio'} class:bg-primary-500/20={shellState.activeOverlay === 'visual'} class:text-primary-400={shellState.activeOverlay === 'visual'} class:bg-amber-500/20={shellState.activeOverlay === 'neural'} class:text-amber-400={shellState.activeOverlay === 'neural'}>
            {#if shellState.activeOverlay === 'audio'}
              <Waves size={24} />
            {:else if shellState.activeOverlay === 'visual'}
              <Hexagon size={24} />
            {:else if shellState.activeOverlay === 'neural'}
              <Network size={24} />
            {/if}
          </div>
          <div>
            <h2 class="text-xl font-bold capitalize">{shellState.activeOverlay} Configuration</h2>
            <p class="text-xs font-mono text-zinc-600 mt-0.5">MODULE.{shellState.activeOverlay?.toUpperCase()}.SETTINGS</p>
          </div>
          <button
            id="vs-overlay-close"
            onclick={() => onOpenOverlay?.(null)}
            class="p-2 rounded-lg hover:bg-white/5 text-zinc-500 hover:text-white transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        <!-- Overlay Content Placeholder -->
        <div id="vs-overlay-content" class="p-8 grid place-items-center text-zinc-600">
          <div class="text-center space-y-4">
            <div class="w-12 h-12 mx-auto border border-dashed border-zinc-800 rounded-full grid place-items-center">
              <div class="w-2 h-2 bg-zinc-700 rounded-full animate-ping"></div>
            </div>
            <p class="font-mono text-sm">Module interface loading...</p>
          </div>
        </div>
      </div>
    </div>
  {/if}

  <!-- Utility Dock -->
  <UtilityDock
    {shellState}
    {settings}
    {presets}
    {onTogglePlayback}
    {onApplyPreset}
    {onUpdateSettings}
    {onOpenOverlay}
  />
</div>

<style>
  @keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
  }
</style>
