<script lang="ts">
  import { Play, Pause, RotateCcw, Mic, Settings, Zap, Activity, Cpu, Brain, Sparkles } from 'lucide-svelte';
  import type { ShellState, SystemSettings, ScenePreset } from '../types';

  interface Props {
    shellState: ShellState;
    settings: SystemSettings;
    presets: ScenePreset[];
    onTogglePlayback?: () => void;
    onApplyPreset?: (id: string) => void;
    onUpdateSettings?: (key: keyof SystemSettings, value: any) => void;
    onOpenOverlay?: (overlay: 'audio' | 'visual' | 'neural' | null) => void;
  }

  let { shellState, settings, presets, onTogglePlayback, onApplyPreset, onUpdateSettings, onOpenOverlay }: Props = $props();

  let activePreset = $derived(presets.find(p => p.id === shellState.currentPresetId));
</script>

<div id="vs-dock-container" class="fixed bottom-6 left-1/2 -translate-x-1/2 z-50">
  <!-- Main Dock -->
  <div id="vs-dock-glass" class="grid grid-flow-col gap-1 items-center px-3 py-2 bg-zinc-900/80 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-2xl shadow-black/50">

    <!-- Transport Group -->
    <div id="vs-group-transport" class="grid grid-flow-col gap-1 items-center">
      <button id="vs-btn-reset" title="Reset" class="relative p-3 rounded-xl transition-all duration-200 hover:scale-110 active:scale-95 text-zinc-500 hover:text-zinc-200 hover:bg-white/5">
        <RotateCcw size={20} strokeWidth={1.5} />
      </button>

      <button
        id="vs-btn-play"
        onclick={onTogglePlayback}
        title={shellState.isPlaying ? 'Pause' : 'Play'}
        class="p-4 rounded-2xl transition-all duration-300 hover:scale-105 active:scale-95"
        class:bg-gradient-to-br={true}
        class:from-primary-500={shellState.isPlaying}
        class:to-primary-600={shellState.isPlaying}
        class:text-black={shellState.isPlaying}
        class:shadow-lg={shellState.isPlaying}
        class:shadow-primary-500/30={shellState.isPlaying}
        class:bg-zinc-800={!shellState.isPlaying}
        class:text-zinc-100={!shellState.isPlaying}
        class:hover:bg-zinc-700={!shellState.isPlaying}
      >
        {#if shellState.isPlaying}
          <Pause size={22} fill="currentColor" />
        {:else}
          <Play size={22} fill="currentColor" class="ml-0.5" />
        {/if}
      </button>
    </div>

    <!-- Divider -->
    <div class="w-px h-8 bg-gradient-to-b from-transparent via-white/10 to-transparent mx-2"></div>

    <!-- Modules Group -->
    <div id="vs-group-modules" class="grid grid-flow-col gap-1 items-center">
      <button
        id="vs-mod-audio"
        title="Audio Core"
        onclick={() => onOpenOverlay?.(shellState.activeOverlay === 'audio' ? null : 'audio')}
        class="relative p-3 rounded-xl transition-all duration-200 hover:scale-110 active:scale-95"
        class:bg-secondary-500/20={shellState.activeOverlay === 'audio'}
        class:text-secondary-400={shellState.activeOverlay === 'audio'}
        class:shadow-[0_0_20px_-5px_rgba(139,92,246,0.4)]={shellState.activeOverlay === 'audio'}
        class:text-zinc-500={shellState.activeOverlay !== 'audio'}
        class:hover:text-zinc-200={shellState.activeOverlay !== 'audio'}
        class:hover:bg-white/5={shellState.activeOverlay !== 'audio'}
      >
        <Activity size={20} strokeWidth={1.5} />
      </button>

      <button
        id="vs-mod-visual"
        title="Visual Engine"
        onclick={() => onOpenOverlay?.(shellState.activeOverlay === 'visual' ? null : 'visual')}
        class="relative p-3 rounded-xl transition-all duration-200 hover:scale-110 active:scale-95"
        class:bg-primary-500/20={shellState.activeOverlay === 'visual'}
        class:text-primary-400={shellState.activeOverlay === 'visual'}
        class:shadow-[0_0_20px_-5px_rgba(16,185,129,0.4)]={shellState.activeOverlay === 'visual'}
        class:text-zinc-500={shellState.activeOverlay !== 'visual'}
        class:hover:text-zinc-200={shellState.activeOverlay !== 'visual'}
        class:hover:bg-white/5={shellState.activeOverlay !== 'visual'}
      >
        <Cpu size={20} strokeWidth={1.5} />
      </button>

      <button
        id="vs-mod-neural"
        title="Neural Link"
        onclick={() => onOpenOverlay?.(shellState.activeOverlay === 'neural' ? null : 'neural')}
        class="relative p-3 rounded-xl transition-all duration-200 hover:scale-110 active:scale-95"
        class:bg-amber-500/20={shellState.activeOverlay === 'neural'}
        class:text-amber-400={shellState.activeOverlay === 'neural'}
        class:shadow-[0_0_20px_-5px_rgba(245,158,11,0.4)]={shellState.activeOverlay === 'neural'}
        class:text-zinc-500={shellState.activeOverlay !== 'neural'}
        class:hover:text-zinc-200={shellState.activeOverlay !== 'neural'}
        class:hover:bg-white/5={shellState.activeOverlay !== 'neural'}
      >
        <Brain size={20} strokeWidth={1.5} />
      </button>
    </div>

    <!-- Divider -->
    <div class="w-px h-8 bg-gradient-to-b from-transparent via-white/10 to-transparent mx-2"></div>

    <!-- Presets Group -->
    <div id="vs-group-presets" class="grid grid-flow-col gap-2 items-center px-2">
      <Sparkles size={14} class="text-zinc-600" />
      <div class="grid grid-flow-col gap-1">
        {#each presets as preset}
          <button
            id="vs-preset-{preset.id}"
            onclick={() => onApplyPreset?.(preset.id)}
            title="{preset.name} ({preset.category})"
            class="w-8 h-8 rounded-lg text-xs font-mono font-bold transition-all duration-200 hover:scale-110"
            class:bg-white/15={shellState.currentPresetId === preset.id}
            class:text-white={shellState.currentPresetId === preset.id}
            class:border={shellState.currentPresetId === preset.id}
            class:border-white/20={shellState.currentPresetId === preset.id}
            class:bg-zinc-800/50={shellState.currentPresetId !== preset.id}
            class:text-zinc-500={shellState.currentPresetId !== preset.id}
            class:hover:text-zinc-300={shellState.currentPresetId !== preset.id}
            class:hover:bg-zinc-800={shellState.currentPresetId !== preset.id}
          >
            {preset.hotkey}
          </button>
        {/each}
      </div>
    </div>

    <!-- Divider -->
    <div class="w-px h-8 bg-gradient-to-b from-transparent via-white/10 to-transparent mx-2"></div>

    <!-- System Group -->
    <div id="vs-group-system" class="grid grid-flow-col gap-1 items-center">
      <button id="vs-btn-mic" title="Audio Input" class="relative p-3 rounded-xl transition-all duration-200 hover:scale-110 active:scale-95 text-zinc-500 hover:text-zinc-200 hover:bg-white/5">
        <Mic size={20} strokeWidth={1.5} />
      </button>

      <button
        id="vs-btn-perf"
        title="Performance Mode"
        onclick={() => onUpdateSettings?.('performanceMode', settings.performanceMode === 'high-performance' ? 'balanced' : 'high-performance')}
        class="relative p-3 rounded-xl transition-all duration-200 hover:scale-110 active:scale-95"
        class:bg-primary-500/20={settings.performanceMode === 'high-performance'}
        class:text-primary-400={settings.performanceMode === 'high-performance'}
        class:shadow-[0_0_20px_-5px_rgba(16,185,129,0.4)]={settings.performanceMode === 'high-performance'}
        class:text-zinc-500={settings.performanceMode !== 'high-performance'}
        class:hover:text-zinc-200={settings.performanceMode !== 'high-performance'}
        class:hover:bg-white/5={settings.performanceMode !== 'high-performance'}
      >
        <Zap size={20} strokeWidth={1.5} />
      </button>

      <button id="vs-btn-settings" title="Settings" class="relative p-3 rounded-xl transition-all duration-200 hover:scale-110 active:scale-95 text-zinc-500 hover:text-zinc-200 hover:bg-white/5">
        <Settings size={20} strokeWidth={1.5} />
      </button>
    </div>
  </div>

  <!-- Status Bar -->
  <div id="vs-status-bar" class="grid grid-flow-col gap-6 justify-center items-center mt-3 text-[10px] font-mono text-zinc-600 uppercase tracking-widest">
    <div id="vs-status-preset" class="grid grid-flow-col gap-2 items-center">
      <span class="text-zinc-500">Scene:</span>
      <span class="text-primary-500">{activePreset?.name || 'None'}</span>
    </div>
    <div id="vs-status-fps" class="grid grid-flow-col gap-2 items-center">
      <div class="w-1.5 h-1.5 rounded-full bg-primary-500 animate-pulse"></div>
      <span>60 FPS</span>
    </div>
    <div id="vs-status-dsp" class="grid grid-flow-col gap-2 items-center">
      <span>DSP</span>
      <span class="text-primary-500">●</span>
    </div>
  </div>
</div>
