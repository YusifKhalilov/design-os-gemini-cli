# Visual Engine Tests

Test instructions for the Visual Engine section.

## Unit Tests

### Canvas Display
- [ ] Renders fullscreen container (w-screen, h-screen)
- [ ] Cursor is hidden (cursor-none class)
- [ ] Background gradient matches palette

### Keyboard Shortcuts
- [ ] Ctrl+Shift+Up calls onLike
- [ ] Ctrl+Shift+Down calls onDislike
- [ ] Prevents default on shortcut keys

### Feedback Animations
- [ ] +1 text appears on like
- [ ] -1 text appears on dislike
- [ ] Particle explosion animates
- [ ] Feedback clears after animation

### HUD Display
- [ ] Shows current state ID
- [ ] Shows geometry style
- [ ] Shows BPM from audio context
- [ ] Shows session rating count

### Controls Visibility
- [ ] Controls hidden initially
- [ ] Controls appear on keypress
- [ ] Controls fade after 3 seconds
- [ ] Keyboard hints are visible

### Color Palettes
- [ ] cyber-neon uses emerald colors
- [ ] deep-ocean uses cyan colors
- [ ] magma uses amber colors
- [ ] monochrome-glitch uses white

## Integration Tests

### Audio Reactivity
- [ ] Visuals respond to audio levels
- [ ] Geometry changes with bass
- [ ] Particles move with treble

### State History
- [ ] Like rating is recorded
- [ ] Dislike rating is recorded
- [ ] Session count updates correctly
