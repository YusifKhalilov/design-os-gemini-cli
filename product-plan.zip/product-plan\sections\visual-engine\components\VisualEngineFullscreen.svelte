<script lang="ts">
  import type { VisualState } from '../types';
  import { onMount, onDestroy } from 'svelte';

  interface Props {
    history: VisualState[];
    currentState: VisualState;
    onLike: () => void;
    onDislike: () => void;
  }

  let { history, currentState, onLike, onDislike }: Props = $props();

  let feedback = $state<'like' | 'dislike' | null>(null);
  let showControls = $state(false);
  let controlTimeout: ReturnType<typeof setTimeout> | null = null;

  function triggerFeedback(type: 'like' | 'dislike') {
    feedback = type;
    setTimeout(() => feedback = null, 1000);
  }

  function handleKeyDown(e: KeyboardEvent) {
    if (e.ctrlKey && e.shiftKey) {
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        onLike();
        triggerFeedback('like');
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        onDislike();
        triggerFeedback('dislike');
      }
    }

    showControls = true;
    if (controlTimeout) clearTimeout(controlTimeout);
    controlTimeout = setTimeout(() => showControls = false, 3000);
  }

  onMount(() => {
    window.addEventListener('keydown', handleKeyDown);
  });

  onDestroy(() => {
    window.removeEventListener('keydown', handleKeyDown);
    if (controlTimeout) clearTimeout(controlTimeout);
  });

  // Color helpers
  function getAccentClass() {
    switch (currentState.palette) {
      case 'cyber-neon': return 'text-primary-500 bg-primary-500';
      case 'deep-ocean': return 'text-cyan-500 bg-cyan-500';
      case 'magma': return 'text-amber-500 bg-amber-500';
      case 'monochrome-glitch': return 'text-white bg-white';
      default: return 'text-primary-500 bg-primary-500';
    }
  }

  let likeCount = $derived(history.filter(h => h.rating === 1).length);
  let dislikeCount = $derived(history.filter(h => h.rating === -1).length);
</script>

<div
  id="visual-engine-container"
  data-testid="visual-engine-container"
  class="relative w-screen h-screen overflow-hidden bg-gradient-to-br from-zinc-900 via-zinc-950 to-black font-body selection:bg-primary-500/30 cursor-none"
>
  <!-- Ambient Background -->
  <div class="absolute inset-0 z-0 pointer-events-none">
    <div
      data-testid="ambient-orb"
      class="absolute top-1/4 left-1/4 w-[40rem] h-[40rem] rounded-full blur-[100px] opacity-20 animate-pulse {getAccentClass().split(' ')[1]}"
    ></div>
    <div class="absolute bottom-1/4 right-1/4 w-[30rem] h-[30rem] rounded-full blur-[100px] opacity-20 animate-pulse {getAccentClass().split(' ')[1]}" style="animation-delay: 1s"></div>
  </div>

  <!-- Main Visualization Canvas -->
  <div class="absolute inset-0 z-10 grid place-items-center">
    <!-- Central Geometric Form -->
    <div class="relative w-96 h-96" style="animation: spin 20s linear infinite;">
      <div class="absolute inset-0 border-2 rotate-45 border-current opacity-30 {getAccentClass().split(' ')[0]}" class:rounded-full={currentState.geometryStyle === 'spherical-swarm'}></div>
      <div class="absolute inset-4 border border-dashed -rotate-45 border-current opacity-20 {getAccentClass().split(' ')[0]}" class:rounded-full={currentState.geometryStyle === 'spherical-swarm'}></div>
    </div>

    <!-- Audio Reactive Spectrum -->
    <div class="absolute bottom-32 left-0 right-0 grid grid-flow-col gap-1 justify-center items-end h-24 px-12">
      {#each Array(64) as _, i}
        <div
          class="w-2 rounded-t-sm transition-all duration-75 opacity-60 {getAccentClass().split(' ')[1]}"
          style="height: {Math.max(10, Math.random() * 100 * (i < 20 ? currentState.audioContext.bassLevel : i < 40 ? currentState.audioContext.midLevel : currentState.audioContext.trebleLevel))}%"
        ></div>
      {/each}
    </div>
  </div>

  <!-- Feedback Overlay -->
  {#if feedback}
    <div class="absolute inset-0 z-50 grid place-items-center pointer-events-none">
      <div class="text-9xl font-bold tracking-tighter mix-blend-screen animate-ping" class:text-primary-400={feedback === 'like'} class:text-rose-500={feedback === 'dislike'}>
        {feedback === 'like' ? '+1' : '-1'}
      </div>
    </div>
  {/if}

  <!-- HUD Info -->
  <div
    class="absolute top-0 left-0 right-0 p-8 grid grid-cols-2 justify-between items-start z-40 transition-opacity duration-500"
    class:opacity-100={showControls}
    class:opacity-0={!showControls}
  >
    <div class="space-y-2">
      <div class="grid grid-flow-col gap-3 items-center justify-start">
        <div class="w-2 h-2 rounded-full animate-pulse {getAccentClass().split(' ')[1]}"></div>
        <h1 class="text-sm font-mono tracking-widest uppercase text-zinc-400">Visual Engine <span class="text-zinc-600">//</span> Live Session</h1>
      </div>
      <div class="space-y-1 font-mono text-xs text-zinc-500">
        <p>ID: <span class="text-zinc-300">{currentState.id}</span></p>
        <p>STYLE: <span class="text-zinc-300 uppercase">{currentState.geometryStyle}</span></p>
        <p>BPM: <span class="text-zinc-300">{currentState.audioContext.tempo}</span></p>
      </div>
    </div>

    <div class="grid justify-end">
      <div class="px-3 py-1 rounded-full border border-zinc-800 bg-zinc-900/50 backdrop-blur-sm text-xs font-mono text-zinc-400">
        Session Rating: <span class="text-primary-400">{likeCount}</span> / <span class="text-rose-400">{dislikeCount}</span>
      </div>
    </div>
  </div>

  <!-- Keyboard Hints -->
  <div
    class="absolute bottom-8 left-0 right-0 grid grid-flow-col gap-8 justify-center font-mono text-xs text-zinc-500 transition-opacity duration-500"
    class:opacity-100={showControls}
    class:opacity-0={!showControls}
  >
    <div class="grid grid-flow-col gap-2 items-center">
      <kbd class="px-2 py-1 rounded bg-zinc-900 border border-zinc-800 text-zinc-300">Ctrl</kbd> +
      <kbd class="px-2 py-1 rounded bg-zinc-900 border border-zinc-800 text-zinc-300">Shift</kbd> +
      <kbd class="px-2 py-1 rounded bg-zinc-900 border border-zinc-800 text-primary-400">↑ Like</kbd>
    </div>
    <div class="grid grid-flow-col gap-2 items-center">
      <kbd class="px-2 py-1 rounded bg-zinc-900 border border-zinc-800 text-zinc-300">Ctrl</kbd> +
      <kbd class="px-2 py-1 rounded bg-zinc-900 border border-zinc-800 text-zinc-300">Shift</kbd> +
      <kbd class="px-2 py-1 rounded bg-zinc-900 border border-zinc-800 text-rose-400">↓ Dislike</kbd>
    </div>
  </div>
</div>

<style>
  @keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
  }
</style>
