# Milestone 01: Foundation

## Overview
Set up the project with design tokens, routing, and application shell structure.

---

## Preamble

### What You're Receiving:
- Design token definitions (colors, typography)
- Shell component code (adapt from React to Svelte 5)
- Routing structure specification

### What You Need to Build:
- Vite + Svelte 5 project configuration
- Tailwind CSS setup with custom theme
- Basic routing (SvelteKit or svelte-routing)
- Shell layout components

### Guidelines:
- Use Svelte 5 Runes (`$state`, `$derived`, `$effect`)
- Follow provided color/font tokens exactly
- Keep shell minimal — it's a container for content

---

## Tasks

### 1.1 Project Setup

```bash
# Create new Svelte 5 project
pnpm create vite vectorhive --template svelte-ts
cd vectorhive

# Install dependencies
pnpm add -D tailwindcss postcss autoprefixer
pnpm add lucide-svelte

# Initialize Tailwind
npx tailwindcss init -p
```

### 1.2 Configure Tailwind

Update `tailwind.config.js`:

```javascript
/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{html,js,svelte,ts}'],
  theme: {
    extend: {
      colors: {
        // Primary: Emerald
        primary: {
          50: '#ecfdf5',
          100: '#d1fae5',
          200: '#a7f3d0',
          300: '#6ee7b7',
          400: '#34d399',
          500: '#10b981',
          600: '#059669',
          700: '#047857',
          800: '#065f46',
          900: '#064e3b',
          950: '#022c22'
        },
        // Secondary: Violet
        secondary: {
          50: '#f5f3ff',
          100: '#ede9fe',
          200: '#ddd6fe',
          300: '#c4b5fd',
          400: '#a78bfa',
          500: '#8b5cf6',
          600: '#7c3aed',
          700: '#6d28d9',
          800: '#5b21b6',
          900: '#4c1d95',
          950: '#2e1065'
        }
      },
      fontFamily: {
        heading: ['Space Grotesk', 'sans-serif'],
        body: ['Manrope', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace']
      },
      animation: {
        'ping-slow': 'ping 2s cubic-bezier(0, 0, 0.2, 1) infinite',
      }
    }
  },
  plugins: []
}
```

### 1.3 Add Google Fonts

In `index.html` (or `app.html` for SvelteKit):

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;700&family=Manrope:wght@400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
```

### 1.4 Create Base Styles

`src/app.css`:

```css
@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  body {
    @apply bg-zinc-950 text-zinc-100 font-body antialiased;
  }

  ::selection {
    @apply bg-primary-500/30;
  }
}

@layer utilities {
  .glass {
    @apply bg-zinc-900/60 backdrop-blur-xl border border-zinc-800/50;
  }

  .glow-primary {
    box-shadow: 0 0 20px -5px theme('colors.primary.500 / 40%');
  }

  .glow-secondary {
    box-shadow: 0 0 20px -5px theme('colors.secondary.500 / 40%');
  }
}
```

### 1.5 Create Routing Structure

For a simple SPA, create these routes/pages:

```
src/
├── routes/
│   ├── +page.svelte       # Home (Visual Engine)
│   ├── +layout.svelte     # Shell wrapper
│   ├── audio/
│   │   └── +page.svelte   # Audio Core
│   ├── neural/
│   │   └── +page.svelte   # Neural Link
│   └── settings/
│       └── +page.svelte   # Vector Shell settings
```

### 1.6 Create Shell Components

#### `src/lib/shell/AppShell.svelte`

```svelte
<script lang="ts">
  import MainNav from './MainNav.svelte';

  interface Props {
    children: any;
  }

  let { children }: Props = $props();
</script>

<div id="app-shell-root" class="fixed inset-0 grid grid-rows-[1fr_auto] overflow-hidden bg-zinc-950 font-body text-zinc-100">
  <!-- Dynamic Background -->
  <div id="visual-engine-bg" class="fixed inset-0 z-0 pointer-events-none">
    <div class="absolute inset-0 bg-gradient-to-br from-zinc-900 via-zinc-950 to-black"></div>

    <!-- Ambient Orbs -->
    <div class="absolute inset-0 opacity-30">
      <div class="absolute top-1/4 left-1/4 w-96 h-96 bg-primary-500/20 rounded-full blur-3xl animate-pulse"></div>
      <div class="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-secondary-600/20 rounded-full blur-3xl animate-pulse" style="animation-delay: 1s"></div>
    </div>

    <!-- Grid Overlay -->
    <div
      class="absolute inset-0 opacity-10"
      style="background-image: radial-gradient(circle, #fff 1px, transparent 1px); background-size: 40px 40px;"
    ></div>
  </div>

  <!-- Main Content -->
  <main id="shell-content" class="relative z-10 grid place-items-center w-full h-full p-6 md:p-12 pointer-events-none">
    <div id="content-wrapper" class="pointer-events-auto max-w-7xl w-full max-h-full overflow-y-auto">
      {@render children()}
    </div>
  </main>

  <!-- Floating Dock -->
  <div id="dock-container" class="fixed bottom-8 left-0 right-0 z-50 grid place-items-center pointer-events-none">
    <MainNav />
  </div>
</div>
```

#### `src/lib/shell/MainNav.svelte`

```svelte
<script lang="ts">
  import { Play, Pause, Waves, Cpu, Brain, Settings } from 'lucide-svelte';

  interface NavItem {
    label: string;
    href: string;
    icon: any;
  }

  let isVisualizing = $state(false);

  const leftItems: NavItem[] = [
    { label: 'Audio Core', href: '/audio', icon: Waves },
    { label: 'Neural Link', href: '/neural', icon: Brain },
  ];

  const rightItems: NavItem[] = [
    { label: 'Visual Engine', href: '/', icon: Cpu },
    { label: 'Settings', href: '/settings', icon: Settings },
  ];

  function togglePlayback() {
    isVisualizing = !isVisualizing;
  }
</script>

<nav id="main-dock" class="pointer-events-auto">
  <div class="grid grid-flow-col gap-2 items-end p-2 rounded-2xl border border-white/10 shadow-2xl backdrop-blur-xl bg-zinc-950/40 hover:bg-zinc-950/60 hover:border-white/20 hover:scale-105 transition-all duration-300">

    <!-- Left Items -->
    <div class="grid grid-flow-col gap-2 place-items-center">
      {#each leftItems as item, idx}
        <a
          id="dock-item-{idx}"
          href={item.href}
          class="group relative grid place-items-center w-10 h-10 rounded-xl transition-all duration-200 text-zinc-400 hover:text-zinc-100 hover:bg-white/10 hover:-translate-y-1"
        >
          <svelte:component this={item.icon} size={20} />
          <div class="absolute -top-10 left-1/2 -translate-x-1/2 px-2 py-1 bg-black/80 text-xs text-white rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none backdrop-blur-sm border border-white/10">
            {item.label}
          </div>
        </a>
      {/each}
    </div>

    <!-- Center Play Button -->
    <div class="grid place-items-center px-4">
      <button
        id="play-trigger"
        onclick={togglePlayback}
        class="group relative grid place-items-center w-14 h-14 rounded-full transition-all duration-300 bg-gradient-to-tr from-primary-600 to-primary-400 text-white shadow-lg shadow-primary-500/20 hover:scale-110 hover:shadow-primary-500/40 active:scale-95"
        class:animate-pulse={isVisualizing}
        class:from-secondary-600={isVisualizing}
        class:to-secondary-400={isVisualizing}
        class:shadow-secondary-500/20={isVisualizing}
      >
        {#if isVisualizing}
          <Pause size={24} fill="currentColor" />
        {:else}
          <Play size={24} fill="currentColor" class="ml-1" />
        {/if}

        {#if !isVisualizing}
          <span class="absolute inline-flex h-full w-full rounded-full bg-primary-400 opacity-20 animate-ping"></span>
        {/if}
      </button>
    </div>

    <!-- Right Items -->
    <div class="grid grid-flow-col gap-2 place-items-center">
      {#each rightItems as item, idx}
        <a
          id="dock-item-right-{idx}"
          href={item.href}
          class="group relative grid place-items-center w-10 h-10 rounded-xl transition-all duration-200 text-zinc-400 hover:text-zinc-100 hover:bg-white/10 hover:-translate-y-1"
        >
          <svelte:component this={item.icon} size={20} />
          <div class="absolute -top-10 left-1/2 -translate-x-1/2 px-2 py-1 bg-black/80 text-xs text-white rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none backdrop-blur-sm border border-white/10">
            {item.label}
          </div>
        </a>
      {/each}
    </div>
  </div>
</nav>
```

---

## Done Criteria

- [ ] Project runs with `pnpm dev`
- [ ] Tailwind classes work with custom colors (`bg-primary-500`, etc.)
- [ ] Google Fonts load correctly (Space Grotesk, Manrope, JetBrains Mono)
- [ ] Basic routing works between pages
- [ ] Shell layout displays with animated background
- [ ] Floating dock is visible and interactive
- [ ] Play/Pause button toggles state

---

## Next Milestone

Proceed to `02-audio-core.md` to implement the Audio Core section.
