<script lang="ts">
  import type { MetricPoint } from '../types';

  interface Props {
    metrics: MetricPoint[];
    status: 'idle' | 'training' | 'paused' | 'completed' | 'stopped';
  }

  let { metrics, status }: Props = $props();

  let accuracyPath = $derived(() => {
    if (metrics.length === 0) return '';
    const maxEpoch = metrics[metrics.length - 1]?.epoch || 100;
    return metrics.map((p, i) => {
      const x = (p.epoch / maxEpoch) * 100;
      const y = (1 - p.accuracy) * 100;
      return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
    }).join(' ');
  });

  let lossPath = $derived(() => {
    if (metrics.length === 0) return '';
    const maxEpoch = metrics[metrics.length - 1]?.epoch || 100;
    return metrics.map((p, i) => {
      const x = (p.epoch / maxEpoch) * 100;
      const yPos = 100 - (Math.min(p.loss, 1) * 100);
      return `${i === 0 ? 'M' : 'L'} ${x} ${yPos}`;
    }).join(' ');
  });
</script>

<div
  data-testid="metrics-chart"
  class="relative w-full h-full bg-zinc-950 rounded-2xl border border-zinc-800/50 overflow-hidden grid grid-rows-[auto_1fr_auto] shadow-2xl shadow-black/50"
>
  <!-- Header / Legend -->
  <div class="absolute top-4 left-6 z-10 grid grid-flow-col gap-6">
    <div class="grid grid-flow-col gap-2 items-center">
      <div class="w-3 h-3 rounded-full bg-primary-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]"></div>
      <span class="text-xs font-mono text-primary-300 uppercase tracking-wider">Accuracy</span>
    </div>
    <div class="grid grid-flow-col gap-2 items-center">
      <div class="w-3 h-3 rounded-full bg-secondary-500 shadow-[0_0_10px_rgba(139,92,246,0.5)]"></div>
      <span class="text-xs font-mono text-secondary-300 uppercase tracking-wider">Loss Function</span>
    </div>
  </div>

  <!-- Grid Background -->
  <div
    class="absolute inset-0 z-0 opacity-20 pointer-events-none"
    style="background-image: linear-gradient(to right, #27272a 1px, transparent 1px), linear-gradient(to bottom, #27272a 1px, transparent 1px); background-size: 40px 40px;"
  ></div>

  <!-- Chart Area -->
  <div class="flex-1 relative p-6 mt-8">
    {#if metrics.length > 0}
      <svg class="w-full h-full overflow-visible" viewBox="0 0 100 100" preserveAspectRatio="none">
        <!-- Accuracy Line -->
        <path
          d={accuracyPath()}
          fill="none"
          stroke="#10b981"
          stroke-width="0.5"
          vector-effect="non-scaling-stroke"
          class="drop-shadow-[0_0_8px_rgba(16,185,129,0.5)]"
        />

        <!-- Loss Line -->
        <path
          d={lossPath()}
          fill="none"
          stroke="#8b5cf6"
          stroke-width="0.5"
          vector-effect="non-scaling-stroke"
          class="drop-shadow-[0_0_8px_rgba(139,92,246,0.5)]"
        />

        <!-- Active dot -->
        {#if status === 'training' && metrics.length > 0}
          <circle
            cx={(metrics[metrics.length-1].epoch / (metrics[metrics.length-1].epoch || 100)) * 100}
            cy={(1 - metrics[metrics.length-1].accuracy) * 100}
            r="1"
            fill="#10b981"
            class="animate-ping origin-center"
          />
        {/if}
      </svg>
    {:else}
      <div class="absolute inset-0 grid place-items-center text-zinc-700 font-mono text-sm">
        WAITING FOR SIGNAL...
      </div>
    {/if}
  </div>

  <!-- Footer -->
  <div class="bg-zinc-900/50 backdrop-blur-md border-t border-zinc-800 p-3 px-6 grid grid-cols-3 text-[10px] text-zinc-500 font-mono uppercase tracking-widest">
    <span>Real-time Rendering</span>
    <span class="text-center">{status === 'training' ? 'Unstable Stream' : 'Stream Offline'}</span>
    <span class="text-right">Canvas: 2048x1024</span>
  </div>
</div>
