<script lang="ts">
  import MainNav from './MainNav.svelte';

  interface Props {
    children: any;
  }

  let { children }: Props = $props();
</script>

<div id="app-shell-root" class="fixed inset-0 grid grid-rows-[1fr_auto] overflow-hidden bg-zinc-950 font-body text-zinc-100 selection:bg-primary-500/30">
  <!-- Dynamic Background / Visual Engine Placeholder -->
  <div id="visual-engine-bg" class="fixed inset-0 z-0 pointer-events-none">
    <div class="absolute inset-0 bg-gradient-to-br from-zinc-900 via-zinc-950 to-black"></div>

    <!-- Abstract animated shapes -->
    <div class="absolute inset-0 opacity-30">
      <div class="absolute top-1/4 left-1/4 w-96 h-96 bg-primary-500/20 rounded-full blur-3xl animate-pulse"></div>
      <div class="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-secondary-600/20 rounded-full blur-3xl animate-pulse" style="animation-delay: 1s"></div>
    </div>

    <!-- Grid Overlay for 'Tech' feel -->
    <div
      class="absolute inset-0 opacity-10"
      style="background-image: radial-gradient(circle, #fff 1px, transparent 1px); background-size: 40px 40px;"
    ></div>
  </div>

  <!-- Main Content Area (Overlay Panels) -->
  <main id="shell-content" class="relative z-10 grid place-items-center w-full h-full p-6 md:p-12 pointer-events-none">
    <!-- Content wrapper - Allows interaction within the content -->
    <div id="content-wrapper" class="pointer-events-auto max-w-7xl w-full max-h-full overflow-y-auto">
      {@render children()}
    </div>
  </main>

  <!-- Floating Dock Navigation -->
  <div id="dock-container" class="fixed bottom-8 left-0 right-0 z-50 grid place-items-center pointer-events-none">
    <MainNav />
  </div>
</div>
