// =============================================================================
// Data Types
// =============================================================================

export interface ModelConfig {
  id: string;
  name: string;
  architecture: 'Dense' | 'CNN' | 'RNN' | 'Custom';
  learningRate: number;
  batchSize: number;
  epochs: number;
  optimizer: 'adam' | 'sgd' | 'rmsprop';
  description: string;
}

export interface Dataset {
  id: string;
  name: string;
  sampleCount: number;
  features: string[];
  created: string;
}

export interface MetricPoint {
  epoch: number;
  loss: number;
  accuracy: number;
}

export interface TrainingSession {
  id: string;
  configId: string;
  datasetId: string;
  status: 'idle' | 'training' | 'paused' | 'completed' | 'stopped';
  currentEpoch: number;
  totalEpochs: number;
  startTime: string;
  loss: number;
  accuracy: number;
  metricsHistory: MetricPoint[];
}

// =============================================================================
// Component Props
// =============================================================================

export interface NeuralLinkProps {
  /** Available model configuration presets */
  modelConfigs: ModelConfig[];
  /** Available datasets for training */
  datasets: Dataset[];
  /** The list of all training sessions (active and past) */
  sessions: TrainingSession[];

  // Actions
  /** Start a new training session with selected config and dataset */
  onStartTraining: (configId: string, datasetId: string) => void;
  /** Pause an active training session */
  onPauseTraining: (sessionId: string) => void;
  /** Resume a paused training session */
  onResumeTraining: (sessionId: string) => void;
  /** Stop/Kill an active training session */
  onStopTraining: (sessionId: string) => void;
  /** Update a model configuration */
  onUpdateConfig: (configId: string, updates: Partial<ModelConfig>) => void;
  /** Create a new model configuration */
  onCreateConfig: (config: Omit<ModelConfig, 'id'>) => void;
}
