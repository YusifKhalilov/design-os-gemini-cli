# VectorHive - Section Implementation Prompt Template

Use this template for incremental, section-by-section implementation.

---

## Variables to Replace

- `{{SECTION_NAME}}` — Human-readable name (e.g., "Audio Core")
- `{{SECTION_ID}}` — Folder name (e.g., "audio-core")
- `{{NN}}` — Milestone number (e.g., "02")

---

## Prompt Template

```
I need you to implement the {{SECTION_NAME}} section of VectorHive.

## Files to Read First

1. `product-plan/product-overview.md` — Product context (always include)
2. `product-plan/instructions/incremental/{{NN}}-{{SECTION_ID}}.md` — This milestone's instructions
3. `product-plan/sections/{{SECTION_ID}}/README.md` — Section specification
4. `product-plan/sections/{{SECTION_ID}}/types.ts` — TypeScript types
5. `product-plan/sections/{{SECTION_ID}}/tests.md` — Test writing guide

## TDD Workflow

Follow this order:

1. **Read the spec** — Understand user flows and UI requirements
2. **Write tests first** — Use tests.md as a guide for what to test
3. **Copy component code** — Adapt Svelte components from components/
4. **Wire up callbacks** — Connect to your state management
5. **Implement data layer** — Fetch/store data as needed
6. **Verify tests pass** — All user flows should work

## Before You Start

Ask me about:

1. **Data Layer:**
   - How should this section fetch/store its data?
   - Should I use stores, context, or props?

2. **Integration:**
   - How does this section connect to existing sections?
   - Are there shared state dependencies?

3. **Scope:**
   - Should I implement full functionality or a subset?
   - Any features to defer to later?

## Tech Stack

- Svelte 5 (Runes mode)
- Tailwind CSS
- TypeScript

## Sample Data

Use `product-plan/sections/{{SECTION_ID}}/sample-data.json` for testing before real APIs.

## Additional Notes

[ADD YOUR SPECIFIC REQUIREMENTS HERE]

```

---

## Example Usage

### For Audio Core (Milestone 02):

Replace:
- `{{SECTION_NAME}}` → `Audio Core`
- `{{SECTION_ID}}` → `audio-core`
- `{{NN}}` → `02`

### For Visual Engine (Milestone 03):

Replace:
- `{{SECTION_NAME}}` → `Visual Engine`
- `{{SECTION_ID}}` → `visual-engine`
- `{{NN}}` → `03`

---

## Milestone Order

| NN | Section ID | Section Name |
|----|------------|--------------|
| 01 | foundation | Foundation (setup) |
| 02 | audio-core | Audio Core |
| 03 | visual-engine | Visual Engine |
| 04 | neural-link | Neural Link |
| 05 | vector-shell | Vector Shell |
