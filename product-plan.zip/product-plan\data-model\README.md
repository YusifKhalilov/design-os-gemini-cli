# Data Model

This directory contains TypeScript types and sample data for VectorHive entities.

## Entities

### AudioSource
Configuration for the active audio input.

### VisualState
Snapshot of generative visual parameters including geometry and colors.

### TrainingEvent
User feedback data linking audio features to visual states.

### ModelConfig
Neural network configuration preset.

### TrainingSession
Training run record with performance metrics.

## Files

- `types.ts` — All TypeScript interfaces
- `sample-data.json` — Combined sample data for all entities
