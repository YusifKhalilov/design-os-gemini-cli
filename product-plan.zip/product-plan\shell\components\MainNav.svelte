<script lang="ts">
  import { Play, Pause, Waves, Cpu, Brain, Settings, User } from 'lucide-svelte';

  interface NavItem {
    label: string;
    href: string;
    icon: any;
    isActive?: boolean;
  }

  interface Props {
    items?: NavItem[];
    onNavigate?: (href: string) => void;
    onPlayToggle?: () => void;
    isVisualizing?: boolean;
  }

  let {
    items = [],
    onNavigate,
    onPlayToggle,
    isVisualizing = false
  }: Props = $props();

  // Default items if none provided
  const defaultLeftItems: NavItem[] = [
    { label: 'Audio Core', href: '/audio', icon: Waves },
    { label: 'Neural Link', href: '/neural', icon: Brain },
  ];

  const defaultRightItems: NavItem[] = [
    { label: 'Visual Engine', href: '/', icon: Cpu },
    { label: 'Settings', href: '/settings', icon: Settings },
  ];

  let leftItems = $derived(items.length > 0 ? items.slice(0, Math.ceil(items.length / 2)) : defaultLeftItems);
  let rightItems = $derived(items.length > 0 ? items.slice(Math.ceil(items.length / 2)) : defaultRightItems);

  function handleNavigate(href: string) {
    onNavigate?.(href);
  }

  function handlePlayToggle() {
    onPlayToggle?.();
  }
</script>

<nav id="main-dock" class="pointer-events-auto">
  <div class="grid grid-flow-col gap-2 items-end p-2 rounded-2xl border border-white/10 shadow-2xl backdrop-blur-xl bg-zinc-950/40 hover:bg-zinc-950/60 hover:border-white/20 hover:scale-105 transition-all duration-300 ease-out">

    <!-- Left Section -->
    <div class="grid grid-flow-col gap-2 place-items-center">
      {#each leftItems as item, idx}
        <button
          id="dock-item-{idx}"
          onclick={() => handleNavigate(item.href)}
          class="group relative grid place-items-center w-10 h-10 rounded-xl transition-all duration-200 hover:bg-white/10 hover:-translate-y-1"
          class:bg-white/10={item.isActive}
          class:text-primary-400={item.isActive}
          class:shadow-glow-primary={item.isActive}
          class:text-zinc-400={!item.isActive}
          class:hover:text-zinc-100={!item.isActive}
        >
          <div class="relative z-10 p-2">
            <svelte:component this={item.icon} size={20} />
          </div>

          <!-- Tooltip -->
          <div class="absolute -top-10 left-1/2 -translate-x-1/2 px-2 py-1 bg-black/80 text-xs text-white rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none backdrop-blur-sm border border-white/10">
            {item.label}
          </div>

          <!-- Active Indicator Dot -->
          {#if item.isActive}
            <div class="absolute -bottom-1 w-1 h-1 rounded-full bg-primary-400 shadow-[0_0_8px_currentColor]"></div>
          {/if}
        </button>
      {/each}
    </div>

    <!-- Center Play Button -->
    <div class="grid place-items-center px-4">
      <button
        id="play-trigger"
        onclick={handlePlayToggle}
        class="group relative grid place-items-center w-14 h-14 rounded-full transition-all duration-300 text-white shadow-lg hover:scale-110 active:scale-95"
        class:bg-gradient-to-tr={true}
        class:from-primary-600={!isVisualizing}
        class:to-primary-400={!isVisualizing}
        class:shadow-primary-500/20={!isVisualizing}
        class:hover:shadow-primary-500/40={!isVisualizing}
        class:from-secondary-600={isVisualizing}
        class:to-secondary-400={isVisualizing}
        class:shadow-secondary-500/20={isVisualizing}
        class:animate-pulse={isVisualizing}
        aria-label={isVisualizing ? "Stop Visualization" : "Start Visualization"}
      >
        {#if isVisualizing}
          <Pause id="icon-pause" size={24} fill="currentColor" />
        {:else}
          <Play id="icon-play" size={24} fill="currentColor" class="ml-1" />
        {/if}

        <!-- Ping effect -->
        {#if !isVisualizing}
          <span class="absolute inline-flex h-full w-full rounded-full bg-primary-400 opacity-20 animate-ping"></span>
        {/if}
      </button>
    </div>

    <!-- Right Section -->
    <div class="grid grid-flow-col gap-2 place-items-center">
      {#each rightItems as item, idx}
        <button
          id="dock-item-right-{idx}"
          onclick={() => handleNavigate(item.href)}
          class="group relative grid place-items-center w-10 h-10 rounded-xl transition-all duration-200 hover:bg-white/10 hover:-translate-y-1"
          class:bg-white/10={item.isActive}
          class:text-primary-400={item.isActive}
          class:text-zinc-400={!item.isActive}
          class:hover:text-zinc-100={!item.isActive}
        >
          <div class="relative z-10 p-2">
            <svelte:component this={item.icon} size={20} />
          </div>

          <!-- Tooltip -->
          <div class="absolute -top-10 left-1/2 -translate-x-1/2 px-2 py-1 bg-black/80 text-xs text-white rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none backdrop-blur-sm border border-white/10">
            {item.label}
          </div>

          {#if item.isActive}
            <div class="absolute -bottom-1 w-1 h-1 rounded-full bg-primary-400 shadow-[0_0_8px_currentColor]"></div>
          {/if}
        </button>
      {/each}

      <!-- Separator -->
      <div class="w-[1px] h-8 bg-white/10 mx-2"></div>

      <!-- User Menu Trigger -->
      <button
        id="user-menu-trigger"
        class="group grid place-items-center w-8 h-8 rounded-full bg-gradient-to-br from-zinc-700 to-zinc-800 border border-white/10 overflow-hidden hover:ring-2 hover:ring-primary-500/50 transition-all shadow-lg"
      >
        <User size={16} class="text-zinc-400 group-hover:text-primary-400" />
      </button>
    </div>
  </div>
</nav>

<style>
  .shadow-glow-primary {
    box-shadow: 0 0 15px rgba(52, 211, 153, 0.3);
  }
</style>
