# Tailwind Color Configuration

Add these colors to your `tailwind.config.js`:

```javascript
/** @type {import('tailwindcss').Config} */
export default {
  theme: {
    extend: {
      colors: {
        // Primary: Emerald
        primary: {
          50: '#ecfdf5',
          100: '#d1fae5',
          200: '#a7f3d0',
          300: '#6ee7b7',
          400: '#34d399',
          500: '#10b981',
          600: '#059669',
          700: '#047857',
          800: '#065f46',
          900: '#064e3b',
          950: '#022c22'
        },
        // Secondary: Violet
        secondary: {
          50: '#f5f3ff',
          100: '#ede9fe',
          200: '#ddd6fe',
          300: '#c4b5fd',
          400: '#a78bfa',
          500: '#8b5cf6',
          600: '#7c3aed',
          700: '#6d28d9',
          800: '#5b21b6',
          900: '#4c1d95',
          950: '#2e1065'
        }
        // Note: Zinc is already in Tailwind's default palette
      }
    }
  }
}
```

## Usage Examples

```html
<!-- Primary colors -->
<div class="bg-primary-500 text-primary-950">Primary</div>
<div class="border-primary-500/50">Border with opacity</div>
<div class="shadow-primary-500/20">Glow effect</div>

<!-- Secondary colors -->
<div class="bg-secondary-500 text-white">Secondary</div>
<div class="text-secondary-400">Accent text</div>

<!-- Neutral (zinc) -->
<div class="bg-zinc-950 text-zinc-100">Dark background</div>
<div class="bg-zinc-900/60 backdrop-blur">Glass effect</div>
```
