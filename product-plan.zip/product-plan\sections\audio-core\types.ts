// =============================================================================
// Data Types
// =============================================================================

export interface AnalysisMetrics {
  /** Normalized peak values for frequency, typically 5 bands [Low...High] */
  peaks: number[]
  /** Whether a beat is currently detected */
  isBeat: boolean
  /** Overall energy level of the signal (0.0 - 1.0) */
  energyLevel: number
}

export interface AudioSource {
  id: string
  /** The type of input source */
  type: 'file' | 'system'
  /** Current operational status of the source */
  status: 'idle' | 'active' | 'error'
  /** Input gain level (0.0 - 1.0) */
  gain: number
  /** Name of the file or "System Audio" label */
  filename: string
  /** Total duration in seconds (null for system audio) */
  duration?: number | null
  /** Current playback position in seconds (null for system audio) */
  currentTime?: number | null
  /** Real-time analysis snapshot */
  analysisMetrics: AnalysisMetrics
}

// =============================================================================
// Component Props
// =============================================================================

export interface AudioCoreProps {
  /** The currently selected active source configuration */
  activeSource: AudioSource
  /** Handler for switching the source type */
  onSourceChange?: (type: 'file' | 'system') => void
  /** Handler for file selection (only relevant in file mode) */
  onFileSelect?: (file: File) => void
  /** Handler for adjusting the input gain */
  onGainChange?: (value: number) => void
  /** Handler for toggling play/pause status */
  onToggleStatus?: () => void
}
