# Audio Core Tests

Test instructions for the Audio Core section.

## Unit Tests

### Source Toggle
- [ ] Displays "File Upload" and "System Audio" buttons
- [ ] Highlights active source type
- [ ] Calls `onSourceChange` when toggled

### Spectrum Analyzer
- [ ] Renders 5 spectrum bars
- [ ] Bar heights correspond to peak values
- [ ] Bars animate smoothly

### Beat Detection
- [ ] Shows "BEAT DETECTED" when isBeat is true
- [ ] Shows "SIGNAL ACTIVE" when isBeat is false
- [ ] Indicator pulses on beat

### Gain Control
- [ ] Displays current gain percentage
- [ ] Slider moves and updates value
- [ ] Calls `onGainChange` on input

### File Input
- [ ] Shows drop zone in file mode
- [ ] Accepts file drag and drop
- [ ] Calls `onFileSelect` with file

### Status Indicators
- [ ] Green indicator for "active" status
- [ ] Red indicator for "error" status
- [ ] Gray indicator for "idle" status

### Display Info
- [ ] Shows filename for file mode
- [ ] Shows duration and current time for files
- [ ] Shows "LIVE" for system audio

## Integration Tests

### Audio Processing
- [ ] Loads audio file successfully
- [ ] Spectrum updates with audio playback
- [ ] Beat detection fires on transients

### System Capture
- [ ] Requests display media permission
- [ ] Handles rejection gracefully
- [ ] Updates spectrum from system audio
