<script lang="ts">
  import type { AudioSource } from '$lib/types';

  interface Props {
    activeSource: AudioSource;
    onSourceChange?: (type: 'file' | 'system') => void;
    onFileSelect?: (file: File) => void;
    onGainChange?: (value: number) => void;
    onToggleStatus?: () => void;
  }

  let {
    activeSource,
    onSourceChange,
    onFileSelect,
    onGainChange,
    onToggleStatus
  }: Props = $props();

  let localGain = $state(activeSource.gain);

  // Sync local gain when prop changes
  $effect(() => {
    localGain = activeSource.gain;
  });

  function handleGainChange(e: Event) {
    const target = e.target as HTMLInputElement;
    const newVal = parseFloat(target.value);
    localGain = newVal;
    onGainChange?.(newVal);
  }

  function handleFileInput(e: Event) {
    const target = e.target as HTMLInputElement;
    const file = target.files?.[0];
    if (file) onFileSelect?.(file);
  }

  function triggerFileInput() {
    document.getElementById('audio-file-input')?.click();
  }
</script>

<div id="audio-core-panel" class="w-full max-w-md mx-auto">
  <!-- Glassmorphism Container -->
  <div class="relative overflow-hidden bg-zinc-900/60 backdrop-blur-xl border border-zinc-800/50 rounded-2xl shadow-2xl shadow-black/50 transition-all duration-500">

    <!-- Header / Status Bar -->
    <div id="audio-header" class="grid grid-cols-[auto_1fr_auto] gap-3 items-center px-6 py-4 border-b border-zinc-800/50 bg-black/20">
      <div
        id="status-indicator"
        class="w-2 h-2 rounded-full"
        class:bg-primary-500={activeSource.status === 'active'}
        class:animate-pulse={activeSource.status === 'active'}
        class:bg-red-500={activeSource.status === 'error'}
        class:bg-zinc-600={activeSource.status === 'idle'}
        data-testid="status-indicator"
      ></div>
      <h2 class="text-sm font-bold tracking-widest text-zinc-300 uppercase font-mono">
        AUDIO INPUT
      </h2>
      <div class="text-[10px] font-mono text-zinc-500">
        {activeSource.type === 'file' ? 'FILE_MODE' : 'SYSTEM_CAPTURE'}
      </div>
    </div>

    <!-- Visualizer Area -->
    <div id="audio-visualizer" class="relative p-6 bg-gradient-to-b from-black/20 to-transparent">
      <!-- Beat Indicator -->
      <div id="beat-indicator" class="grid grid-flow-col gap-2 items-center mb-2 justify-start">
        <div
          class="w-3 h-3 rounded-full transition-all duration-75"
          class:bg-primary-400={activeSource.analysisMetrics.isBeat}
          class:shadow-[0_0_12px_rgba(52,211,153,0.8)]={activeSource.analysisMetrics.isBeat}
          class:scale-125={activeSource.analysisMetrics.isBeat}
          class:bg-primary-900/50={!activeSource.analysisMetrics.isBeat}
        ></div>
        <span class="text-[10px] uppercase tracking-wider text-primary-500/80 font-mono font-bold">
          {activeSource.analysisMetrics.isBeat ? 'BEAT DETECTED' : 'SIGNAL ACTIVE'}
        </span>
      </div>

      <!-- Spectrum Analyzer Bars -->
      <div id="spectrum-bars" class="grid grid-cols-5 gap-1 h-32 items-end px-4 mb-6">
        {#each activeSource.analysisMetrics.peaks as value, i}
          <div
            data-testid="spectrum-bar"
            class="relative bg-primary-500/20 rounded-t-sm overflow-hidden transition-all duration-100 ease-out"
            style="height: {Math.max(5, value * 100)}%"
          >
            <div
              class="absolute bottom-0 left-0 w-full bg-primary-400 transition-all duration-75"
              style="height: {activeSource.analysisMetrics.isBeat ? '100%' : '90%'}; opacity: {activeSource.analysisMetrics.isBeat ? 1 : 0.7}"
            ></div>
            <div class="absolute top-0 left-0 w-full h-1 bg-primary-200/50"></div>
          </div>
        {/each}
      </div>

      <!-- Info Overlay -->
      <div id="audio-info" class="grid grid-cols-[1fr_auto] justify-between items-end font-mono text-xs text-zinc-500 mt-2">
        <div class="truncate max-w-[200px]" title={activeSource.filename}>
          {activeSource.filename || 'No file selected'}
        </div>
        <div>
          {#if activeSource.duration && activeSource.currentTime !== null}
            {activeSource.currentTime?.toFixed(1)}s / {activeSource.duration.toFixed(1)}s
          {:else}
            LIVE
          {/if}
        </div>
      </div>
    </div>

    <!-- Controls Area -->
    <div id="audio-controls" class="p-6 pt-2 space-y-6">
      <!-- Source Selection Toggle -->
      <div id="source-toggle" class="grid grid-cols-2 gap-1 p-1 bg-black/40 rounded-lg border border-zinc-800">
        <button
          id="btn-file-mode"
          onclick={() => onSourceChange?.('file')}
          class="py-2 text-xs font-bold uppercase tracking-wider rounded-md transition-all"
          class:bg-zinc-700={activeSource.type === 'file'}
          class:text-primary-400={activeSource.type === 'file'}
          class:shadow-sm={activeSource.type === 'file'}
          class:text-zinc-500={activeSource.type !== 'file'}
          class:hover:text-zinc-300={activeSource.type !== 'file'}
          class:hover:bg-white/5={activeSource.type !== 'file'}
        >
          File Upload
        </button>
        <button
          id="btn-system-mode"
          onclick={() => onSourceChange?.('system')}
          class="py-2 text-xs font-bold uppercase tracking-wider rounded-md transition-all"
          class:bg-zinc-700={activeSource.type === 'system'}
          class:text-primary-400={activeSource.type === 'system'}
          class:shadow-sm={activeSource.type === 'system'}
          class:text-zinc-500={activeSource.type !== 'system'}
          class:hover:text-zinc-300={activeSource.type !== 'system'}
          class:hover:bg-white/5={activeSource.type !== 'system'}
        >
          System Audio
        </button>
      </div>

      <!-- File Drop Zone (only in file mode) -->
      {#if activeSource.type === 'file'}
        <div
          id="file-drop-zone"
          class="border-2 border-dashed border-zinc-700 rounded-lg p-6 text-center transition-colors hover:border-primary-500/50 hover:bg-primary-500/5 cursor-pointer group"
          onclick={triggerFileInput}
          role="button"
          tabindex="0"
        >
          <input
            type="file"
            id="audio-file-input"
            class="hidden"
            accept="audio/*"
            onchange={handleFileInput}
          />
          <div class="text-zinc-400 text-xs font-mono group-hover:text-primary-400">
            DROP FILE OR CLICK TO BROWSE
          </div>
        </div>
      {/if}

      <!-- Gain Slider -->
      <div id="gain-control" class="space-y-3">
        <div class="grid grid-cols-2 justify-between text-[10px] uppercase tracking-wider font-bold text-zinc-500 font-mono">
          <span>Input Gain</span>
          <span class="text-primary-500/80 text-right">{(localGain * 100).toFixed(0)}%</span>
        </div>

        <div class="relative h-2 bg-black/50 rounded-full overflow-hidden">
          <div class="absolute inset-0 bg-zinc-800"></div>
          <div
            class="absolute top-0 left-0 h-full bg-primary-500"
            style="width: {localGain * 100}%"
          ></div>
          <input
            type="range"
            min="0"
            max="1"
            step="0.01"
            value={localGain}
            oninput={handleGainChange}
            class="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            aria-label="Input Gain"
          />
        </div>
      </div>
    </div>

    <!-- Footer Glow -->
    <div class="absolute -bottom-10 left-0 right-0 h-20 bg-primary-500/10 blur-2xl pointer-events-none"></div>
  </div>
</div>
