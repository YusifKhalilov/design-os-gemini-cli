# VectorHive - Complete Implementation Instructions

This document contains all milestones combined for one-shot implementation.

---

## Preamble: What You're Receiving

### You Have:
- **UI Designs** — Svelte 5 component code with complete styling
- **Data Model** — TypeScript types for all entities
- **Specifications** — User flows and requirements for each section
- **Test Instructions** — Guidance on what to test (TDD approach)
- **Sample Data** — JSON files for testing before real APIs

### You Need to Build:
- **Audio Processing** — Web Audio API integration for spectrum analysis
- **Graphics Engine** — WebGL/Canvas rendering for visualizations
- **ML Pipeline** — TensorFlow.js model training and inference
- **State Management** — Svelte stores and reactive state
- **Data Persistence** — LocalStorage/IndexedDB for preferences

### Important Guidelines:
1. **Don't redesign components** — Use provided styling, adapt to Svelte 5
2. **Wire up callbacks** — Components expect callback props, connect them
3. **Implement empty states** — Handle loading, error, and no-data cases
4. **Use TDD** — Write tests for user flows before implementing logic
5. **Components are portable** — They accept data via props

---

## Milestone 1: Foundation

### Overview
Set up the project with design tokens, routing, and application shell.

### Tasks

#### 1.1 Project Setup
```bash
pnpm create vite vectorhive --template svelte-ts
cd vectorhive
pnpm add -D tailwindcss postcss autoprefixer
pnpm add -D @sveltejs/adapter-static
pnpm add lucide-svelte
npx tailwindcss init -p
```

#### 1.2 Configure Tailwind
Update `tailwind.config.js`:
```javascript
export default {
  content: ['./src/**/*.{html,js,svelte,ts}'],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#ecfdf5', 100: '#d1fae5', 200: '#a7f3d0',
          300: '#6ee7b7', 400: '#34d399', 500: '#10b981',
          600: '#059669', 700: '#047857', 800: '#065f46',
          900: '#064e3b', 950: '#022c22'
        },
        secondary: {
          50: '#f5f3ff', 100: '#ede9fe', 200: '#ddd6fe',
          300: '#c4b5fd', 400: '#a78bfa', 500: '#8b5cf6',
          600: '#7c3aed', 700: '#6d28d9', 800: '#5b21b6',
          900: '#4c1d95', 950: '#2e1065'
        }
      },
      fontFamily: {
        heading: ['Space Grotesk', 'sans-serif'],
        body: ['Manrope', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace']
      }
    }
  },
  plugins: []
}
```

#### 1.3 Add Google Fonts
In `app.html`:
```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;700&family=Manrope:wght@400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
```

#### 1.4 Create CSS Custom Properties
Copy `design-system/tokens.css` to `src/tokens.css` and import in `app.css`.

#### 1.5 Set Up Routing
Create basic page structure:
- `/` — Home / Visual Engine (fullscreen)
- `/audio` — Audio Core overlay
- `/neural` — Neural Link dashboard
- `/settings` — Vector Shell settings

#### 1.6 Create Shell Component
Adapt `shell/components/` to Svelte 5:
- `AppShell.svelte` — Main layout wrapper
- `MainNav.svelte` — Floating dock navigation
- `UserMenu.svelte` — User dropdown (optional for local app)

### Done Criteria
- [ ] Project runs with `pnpm dev`
- [ ] Tailwind classes work with custom colors
- [ ] Fonts load correctly
- [ ] Basic routing works
- [ ] Shell layout displays

---

## Milestone 2: Audio Core

### Overview
Audio input panel with source selection, spectrum analyzer, and gain control.

### Key Functionality
- Toggle between File Upload and System Audio Capture
- Real-time spectrum visualization (5-band)
- Beat detection indicator
- Input gain slider
- Floating glassmorphic panel

### TDD: Tests to Write First
```typescript
describe('AudioCore', () => {
  it('should display source toggle (File/System)')
  it('should show spectrum analyzer bars')
  it('should indicate beat detection')
  it('should allow gain adjustment via slider')
  it('should handle file drop/selection')
  it('should show error state when system audio unavailable')
  it('should display filename and duration for file mode')
  it('should show "LIVE" indicator for system mode')
})
```

### Components to Adapt
From `sections/audio-core/components/`:
- `AudioCore.svelte` — Main panel component

### Callback Props to Wire Up
| Prop | Type | Description |
|------|------|-------------|
| `onSourceChange` | `(type: 'file' \| 'system') => void` | Source toggle |
| `onFileSelect` | `(file: File) => void` | File input |
| `onGainChange` | `(value: number) => void` | Gain slider |
| `onToggleStatus` | `() => void` | Play/pause |

### Data Layer
- Create `audioStore.ts` with reactive state for `AudioSource`
- Implement Web Audio API for spectrum analysis
- Use `getDisplayMedia()` for system audio (with fallback)

### Empty States
- No file selected: "DROP FILE OR CLICK TO BROWSE"
- System audio error: Show error status indicator
- No signal: Flat spectrum bars

### Done Criteria
- [ ] Source toggle switches between modes
- [ ] File drag-and-drop works
- [ ] Spectrum bars animate with audio
- [ ] Beat indicator pulses on beat
- [ ] Gain slider adjusts input level
- [ ] All tests pass

---

## Milestone 3: Visual Engine

### Overview
Fullscreen generative canvas with audio-reactive visuals and user feedback.

### Key Functionality
- Fullscreen WebGL/Canvas visualization
- Geometry layer synced to audio beats
- Particle layer for atmospheric motion
- Keyboard shortcuts: Ctrl+Shift+Up (Like), Ctrl+Shift+Down (Dislike)
- Playful +1/-1 particle feedback animations
- HUD overlay with session info

### TDD: Tests to Write First
```typescript
describe('VisualEngine', () => {
  it('should display fullscreen canvas')
  it('should respond to audio input')
  it('should handle Ctrl+Shift+Up for like')
  it('should handle Ctrl+Shift+Down for dislike')
  it('should show +1 feedback animation on like')
  it('should show -1 feedback animation on dislike')
  it('should display current visual state info')
  it('should show keyboard hints on interaction')
  it('should track session rating count')
})
```

### Components to Adapt
From `sections/visual-engine/components/`:
- `VisualEngineFullscreen.svelte` — Main fullscreen component

### Callback Props to Wire Up
| Prop | Type | Description |
|------|------|-------------|
| `onLike` | `() => void` | User likes current state |
| `onDislike` | `() => void` | User dislikes current state |

### Data Layer
- Create `visualStore.ts` with `VisualState` and history
- Connect to audio store for reactive parameters
- Store ratings for ML training data

### Empty States
- No audio: Static ambient animation
- Loading: Startup animation sequence

### Done Criteria
- [ ] Canvas fills screen
- [ ] Visuals react to audio input
- [ ] Keyboard shortcuts work
- [ ] Feedback animations play
- [ ] Session info displays correctly
- [ ] All tests pass

---

## Milestone 4: Neural Link

### Overview
TensorFlow.js model training dashboard with real-time metrics.

### Key Functionality
- Model architecture selection
- Hyperparameter controls (learning rate, batch size, epochs, optimizer)
- Training lifecycle (start/pause/resume/stop)
- Real-time loss/accuracy chart
- Metric cards with trends
- Dataset selector

### TDD: Tests to Write First
```typescript
describe('NeuralLink', () => {
  it('should display model config options')
  it('should allow hyperparameter adjustment')
  it('should start training on button click')
  it('should pause/resume training')
  it('should stop training')
  it('should display real-time metrics chart')
  it('should update metric cards during training')
  it('should show training status indicator')
  it('should disable config during active training')
})
```

### Components to Adapt
From `sections/neural-link/components/`:
- `NeuralLinkDashboard.svelte` — Main dashboard
- `ControlPanel.svelte` — Hyperparameter controls
- `TrainingControls.svelte` — Start/Pause/Stop buttons
- `VisualizationDashboard.svelte` — Metrics chart
- `MetricCard.svelte` — Individual metric display

### Callback Props to Wire Up
| Prop | Type | Description |
|------|------|-------------|
| `onStartTraining` | `(configId, datasetId) => void` | Start training |
| `onPauseTraining` | `(sessionId) => void` | Pause session |
| `onResumeTraining` | `(sessionId) => void` | Resume session |
| `onStopTraining` | `(sessionId) => void` | Stop session |
| `onUpdateConfig` | `(configId, updates) => void` | Edit config |

### Data Layer
- Create `neuralStore.ts` with model configs, datasets, sessions
- Implement TensorFlow.js training loop (or mock)
- Store metrics history for charting

### Empty States
- No sessions: "WAITING FOR SIGNAL..."
- Loading model: Show initialization state
- Training complete: "Convergence Reached" toast

### Done Criteria
- [ ] All model configs display
- [ ] Hyperparameter sliders work
- [ ] Training can start/pause/resume/stop
- [ ] Chart updates in real-time
- [ ] Metric cards show current values
- [ ] All tests pass

---

## Milestone 5: Vector Shell

### Overview
HUD overlay container with utility dock and deep configuration overlays.

### Key Functionality
- Persistent floating utility dock
- Transport controls (Play/Pause/Reset)
- Module buttons (Audio/Visual/Neural)
- Preset quick-switcher (1-5 hotkeys)
- System settings (Performance mode, etc.)
- Full-screen configuration overlays
- FPS and status indicators

### TDD: Tests to Write First
```typescript
describe('VectorShell', () => {
  it('should display utility dock')
  it('should toggle playback on click')
  it('should open module overlays')
  it('should close overlay on X click')
  it('should switch presets via buttons')
  it('should toggle performance mode')
  it('should show current preset name')
  it('should display FPS counter')
  it('should respond to keyboard hotkeys')
})
```

### Components to Adapt
From `sections/vector-shell/components/`:
- `VectorShell.svelte` — Main HUD container
- `UtilityDock.svelte` — Bottom dock component

### Callback Props to Wire Up
| Prop | Type | Description |
|------|------|-------------|
| `onTogglePlayback` | `() => void` | Play/Pause |
| `onOpenOverlay` | `(overlay) => void` | Open module config |
| `onApplyPreset` | `(presetId) => void` | Switch scene preset |
| `onUpdateSettings` | `(key, value) => void` | Update system setting |

### Data Layer
- Create `shellStore.ts` with shell state, settings, presets
- Connect to visual store for playback state
- Persist settings to localStorage

### Empty States
- No preset: Show default "VECTOR" title
- Overlay loading: Show loading spinner

### Done Criteria
- [ ] Dock displays and floats correctly
- [ ] All dock buttons work
- [ ] Overlays open and close
- [ ] Presets switch correctly
- [ ] Settings persist
- [ ] All tests pass

---

## Final Integration

After all milestones:

1. **Connect all stores** — Ensure data flows correctly between sections
2. **End-to-end testing** — Test complete user journeys
3. **Performance optimization** — Profile and optimize render loops
4. **Polish** — Animations, transitions, edge cases
5. **Build and deploy** — Create production bundle

### Complete User Journeys to Test

1. **First Launch:** App loads → Visual engine shows ambient → Dock visible
2. **Audio Setup:** Click Audio → Upload file → See spectrum → Close overlay
3. **Training Loop:** Start visuals → Rate with shortcuts → See +1/-1 feedback
4. **ML Training:** Open Neural → Configure → Start training → Watch metrics
5. **Preset Switching:** Click preset buttons → Visual style changes
