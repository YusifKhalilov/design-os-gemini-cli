# Milestone 03: Visual Engine

## Overview
Fullscreen generative canvas with audio-reactive visuals and user feedback loop.

---

## Preamble

### What You're Receiving:
- `VisualEngineFullscreen.svelte` component with complete UI
- TypeScript types for VisualState and AudioContext
- Visual state sample data

### What You Need to Build:
- WebGL or Canvas 2D rendering engine
- Audio-reactive visual parameters
- Keyboard shortcut handling
- Feedback animation system
- Visual state history tracking

### Guidelines:
- Fullscreen canvas, no shell chrome
- Cursor hidden during visualization
- Controls appear on any key press, fade after 3s

---

## Files to Reference

- `product-plan/sections/visual-engine/README.md` — Full specification
- `product-plan/sections/visual-engine/types.ts` — TypeScript types
- `product-plan/sections/visual-engine/components/VisualEngineFullscreen.svelte` — UI component
- `product-plan/sections/visual-engine/sample-data.json` — Test data
- `product-plan/sections/visual-engine/tests.md` — Test writing guide

---

## Key Functionality

1. **Fullscreen Canvas:** WebGL/Canvas covering entire viewport
2. **Audio Reactivity:** Geometry and particles respond to audio features
3. **User Training:** Ctrl+Shift+Up (Like) / Ctrl+Shift+Down (Dislike)
4. **Feedback:** Playful +1/-1 particle animations
5. **HUD Overlay:** Session info, keyboard hints (fade on idle)

---

## TDD: Write These Tests First

```typescript
import { render, screen, fireEvent } from '@testing-library/svelte';
import VisualEngineFullscreen from './VisualEngineFullscreen.svelte';

describe('VisualEngineFullscreen', () => {
  const mockState = {
    id: 'vs-001',
    geometryStyle: 'cubic-lattice',
    palette: 'cyber-neon',
    particleCount: 500,
    particleSpeed: 1.2,
    rating: null,
    audioContext: { bassLevel: 0.8, midLevel: 0.5, trebleLevel: 0.6, tempo: 128 }
  };

  it('should render fullscreen container', () => {
    render(VisualEngineFullscreen, {
      props: { currentState: mockState, history: [], onLike: vi.fn(), onDislike: vi.fn() }
    });
    const container = screen.getByTestId('visual-engine-container');
    expect(container).toHaveClass('w-screen', 'h-screen');
  });

  it('should hide cursor during visualization', () => {
    render(VisualEngineFullscreen, {
      props: { currentState: mockState, history: [], onLike: vi.fn(), onDislike: vi.fn() }
    });
    const container = screen.getByTestId('visual-engine-container');
    expect(container).toHaveClass('cursor-none');
  });

  it('should call onLike when Ctrl+Shift+Up is pressed', async () => {
    const onLike = vi.fn();
    render(VisualEngineFullscreen, {
      props: { currentState: mockState, history: [], onLike, onDislike: vi.fn() }
    });

    await fireEvent.keyDown(window, { key: 'ArrowUp', ctrlKey: true, shiftKey: true });
    expect(onLike).toHaveBeenCalled();
  });

  it('should call onDislike when Ctrl+Shift+Down is pressed', async () => {
    const onDislike = vi.fn();
    render(VisualEngineFullscreen, {
      props: { currentState: mockState, history: [], onLike: vi.fn(), onDislike }
    });

    await fireEvent.keyDown(window, { key: 'ArrowDown', ctrlKey: true, shiftKey: true });
    expect(onDislike).toHaveBeenCalled();
  });

  it('should show +1 feedback animation on like', async () => {
    const { component } = render(VisualEngineFullscreen, {
      props: { currentState: mockState, history: [], onLike: vi.fn(), onDislike: vi.fn() }
    });

    await fireEvent.keyDown(window, { key: 'ArrowUp', ctrlKey: true, shiftKey: true });
    expect(screen.getByText('+1')).toBeInTheDocument();
  });

  it('should show -1 feedback animation on dislike', async () => {
    render(VisualEngineFullscreen, {
      props: { currentState: mockState, history: [], onLike: vi.fn(), onDislike: vi.fn() }
    });

    await fireEvent.keyDown(window, { key: 'ArrowDown', ctrlKey: true, shiftKey: true });
    expect(screen.getByText('-1')).toBeInTheDocument();
  });

  it('should display current visual state ID', () => {
    render(VisualEngineFullscreen, {
      props: { currentState: mockState, history: [], onLike: vi.fn(), onDislike: vi.fn() }
    });
    expect(screen.getByText(/vs-001/)).toBeInTheDocument();
  });

  it('should display geometry style', () => {
    render(VisualEngineFullscreen, {
      props: { currentState: mockState, history: [], onLike: vi.fn(), onDislike: vi.fn() }
    });
    expect(screen.getByText(/CUBIC-LATTICE/i)).toBeInTheDocument();
  });

  it('should show session rating counts', () => {
    const history = [
      { ...mockState, id: '1', rating: 1 },
      { ...mockState, id: '2', rating: 1 },
      { ...mockState, id: '3', rating: -1 },
    ];
    render(VisualEngineFullscreen, {
      props: { currentState: mockState, history, onLike: vi.fn(), onDislike: vi.fn() }
    });
    expect(screen.getByText(/2/)).toBeInTheDocument(); // likes
    expect(screen.getByText(/1/)).toBeInTheDocument(); // dislikes
  });

  it('should show keyboard hints on key press', async () => {
    render(VisualEngineFullscreen, {
      props: { currentState: mockState, history: [], onLike: vi.fn(), onDislike: vi.fn() }
    });

    await fireEvent.keyDown(window, { key: 'a' });
    expect(screen.getByText(/Ctrl/)).toBeVisible();
  });

  it('should apply correct color palette', () => {
    render(VisualEngineFullscreen, {
      props: { currentState: mockState, history: [], onLike: vi.fn(), onDislike: vi.fn() }
    });
    // Check for emerald colors when palette is 'cyber-neon'
    const orb = screen.getByTestId('ambient-orb');
    expect(orb).toHaveClass('bg-emerald-500');
  });
});
```

---

## Visual State Types

```typescript
interface AudioContext {
  bassLevel: number;    // 0-1
  midLevel: number;     // 0-1
  trebleLevel: number;  // 0-1
  tempo: number;        // BPM
}

interface VisualState {
  id: string;
  timestamp: string;
  geometryStyle: 'cubic-lattice' | 'spherical-swarm' | 'architectural-lines' | 'organic-mesh';
  palette: 'cyber-neon' | 'deep-ocean' | 'magma' | 'monochrome-glitch';
  particleCount: number;
  particleSpeed: number;
  rating: 1 | -1 | null;
  audioContext: AudioContext;
}
```

---

## Callback Props

| Prop | Type | Description |
|------|------|-------------|
| `currentState` | `VisualState` | Active visual configuration |
| `history` | `VisualState[]` | Past states in this session |
| `onLike` | `() => void` | User approves current state |
| `onDislike` | `() => void` | User rejects current state |

---

## Color Palette Mapping

| Palette | Primary Color | Tailwind Class |
|---------|---------------|----------------|
| cyber-neon | Emerald | `text-emerald-500`, `bg-emerald-500` |
| deep-ocean | Cyan | `text-cyan-500`, `bg-cyan-500` |
| magma | Amber | `text-amber-500`, `bg-amber-500` |
| monochrome-glitch | White | `text-white`, `bg-white` |

---

## Empty States

| State | Display |
|-------|---------|
| No audio input | Static ambient animation, reduced motion |
| Loading | Startup sequence animation |
| Error | Fallback gradient with error indicator |

---

## Done Criteria

- [ ] Canvas fills entire screen
- [ ] Visuals respond to audio input levels
- [ ] Ctrl+Shift+Up triggers like + callback
- [ ] Ctrl+Shift+Down triggers dislike + callback
- [ ] +1/-1 particle animations play on feedback
- [ ] HUD shows state info (ID, style, BPM)
- [ ] Keyboard hints appear/fade correctly
- [ ] Session rating count updates
- [ ] All tests pass

---

## Next Milestone

Proceed to `04-neural-link.md` to implement the Neural Link section.
