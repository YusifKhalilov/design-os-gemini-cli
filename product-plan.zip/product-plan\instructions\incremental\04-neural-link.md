# Milestone 04: Neural Link

## Overview
TensorFlow.js model training dashboard with real-time metrics.

---

## Key Functionality
1. Model architecture selection
2. Hyperparameter controls
3. Training lifecycle (start/pause/resume/stop)
4. Real-time loss/accuracy chart
5. Metric cards with trends

## Files to Reference
- `product-plan/sections/neural-link/README.md`
- `product-plan/sections/neural-link/types.ts`
- `product-plan/sections/neural-link/components/`
- `product-plan/sections/neural-link/tests.md`

## Component Props

| Prop | Type | Description |
|------|------|-------------|
| `modelConfigs` | `ModelConfig[]` | Available configurations |
| `datasets` | `Dataset[]` | Training datasets |
| `sessions` | `TrainingSession[]` | Training sessions |
| `onStartTraining` | `(configId, datasetId) => void` | Start session |
| `onPauseTraining` | `(sessionId) => void` | Pause session |
| `onResumeTraining` | `(sessionId) => void` | Resume session |
| `onStopTraining` | `(sessionId) => void` | Stop session |
| `onUpdateConfig` | `(configId, updates) => void` | Edit config |

## Done Criteria
- [ ] All model configs display in sidebar
- [ ] Hyperparameter controls work
- [ ] Training lifecycle works
- [ ] Chart updates in real-time
- [ ] Metric cards show values
- [ ] All tests pass

## Next: `05-vector-shell.md`
