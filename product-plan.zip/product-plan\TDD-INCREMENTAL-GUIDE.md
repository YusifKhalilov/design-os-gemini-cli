# TDD + Incremental Implementation Guide

This guide explains exactly how to instruct your coding AI (Claude, Gemini, etc.) to build VectorHive step-by-step using Test-Driven Development.

---

## Overview: The Workflow

For **each milestone**, you'll have a conversation with your AI that follows this pattern:

1. **Context Phase** — Give the AI all necessary files to read
2. **Clarification Phase** — Answer the AI's questions about your preferences
3. **TDD Phase** — AI writes tests first based on tests.md
4. **Implementation Phase** — AI implements code to make tests pass
5. **Verification Phase** — Run tests, fix issues, commit

---

## Milestone 1: Foundation

### Step 1: Start a New Chat

Copy and paste this prompt:

```
I need you to set up the foundation for VectorHive, a Svelte 5 music visualization app.

## Read These Files First

Please read these files before asking questions:
- product-plan/product-overview.md
- product-plan/instructions/incremental/01-foundation.md
- product-plan/design-system/tokens.css
- product-plan/design-system/fonts.md

## Your Task

Set up a new Svelte 5 + Vite project with:
1. Tailwind CSS configured with our color tokens
2. Google Fonts (Space Grotesk, Manrope, JetBrains Mono)
3. Basic routing structure
4. Shell components (AppShell, MainNav)

## Before You Start

Ask me about:
1. Should I use SvelteKit or plain Vite + svelte-routing?
2. Any additional dependencies you want pre-installed?
3. Where should I create the project?

## Tech Stack
- Svelte 5 (Runes mode: $state, $derived, $effect)
- TypeScript
- Tailwind CSS
- pnpm (not npm)
```

### Step 2: Answer Questions

The AI will ask clarifying questions. Example answers:
- "Use SvelteKit for routing"
- "Install lucide-svelte for icons"
- "Create it in a new folder called `vectorhive`"

### Step 3: Let AI Implement

The AI will create the project and shell components.

### Step 4: Verify

```bash
cd vectorhive
pnpm dev
```

Confirm the shell displays with the floating dock.

---

## Milestone 2: Audio Core

### Step 1: Start with Context

```
Now let's implement the Audio Core section using TDD.

## Read These Files

- product-plan/product-overview.md (refresh context)
- product-plan/instructions/incremental/02-audio-core.md
- product-plan/sections/audio-core/README.md
- product-plan/sections/audio-core/types.ts
- product-plan/sections/audio-core/tests.md
- product-plan/sections/audio-core/components/AudioCore.svelte

## TDD Workflow

1. First, write tests based on tests.md
2. Then, adapt the Svelte component
3. Finally, wire up the audio store

## Before You Start

Ask me about:
1. Should I implement actual Web Audio API, or mock it for now?
2. How should I handle system audio capture (getDisplayMedia)?
3. What test framework should I use (Vitest, Testing Library)?
```

### Step 2: Answer Questions

Example answers:
- "Use Vitest + @testing-library/svelte"
- "Mock the Web Audio API for now, we'll implement real audio later"
- "Skip system audio capture for now, just implement file upload"

### Step 3: TDD Cycle

The AI should:
1. **Write failing tests** from tests.md
2. **Copy/adapt the AudioCore.svelte** component
3. **Create audioStore.ts** with reactive state
4. **Make tests pass**

### Step 4: Verify

```bash
pnpm test
pnpm dev
```

---

## Milestone 3: Visual Engine

### Prompt

```
Now let's implement the Visual Engine section using TDD.

## Read These Files

- product-plan/product-overview.md
- product-plan/instructions/incremental/03-visual-engine.md
- product-plan/sections/visual-engine/README.md
- product-plan/sections/visual-engine/types.ts
- product-plan/sections/visual-engine/tests.md
- product-plan/sections/visual-engine/components/VisualEngineFullscreen.svelte

## TDD Workflow

1. Write tests for keyboard shortcuts and feedback animations
2. Adapt the VisualEngineFullscreen component
3. Create visualStore.ts for state management

## Questions to Ask Me

1. Should I implement actual WebGL rendering, or use CSS/Canvas placeholder?
2. How should visual state connect to audio input?
3. Should ratings be persisted?
```

---

## Milestone 4: Neural Link

### Prompt

```
Now let's implement the Neural Link section using TDD.

## Read These Files

- product-plan/product-overview.md
- product-plan/instructions/incremental/04-neural-link.md
- product-plan/sections/neural-link/README.md
- product-plan/sections/neural-link/types.ts
- product-plan/sections/neural-link/tests.md
- product-plan/sections/neural-link/components/ (all files)

## TDD Workflow

1. Write tests for training controls and metrics display
2. Adapt all Neural Link components
3. Create neuralStore.ts for model configs and sessions

## Questions to Ask Me

1. Should I implement actual TensorFlow.js, or mock the training loop?
2. How should training data be collected from user ratings?
3. Should I persist model configs to localStorage?
```

---

## Milestone 5: Vector Shell

### Prompt

```
Finally, let's implement the Vector Shell section using TDD.

## Read These Files

- product-plan/product-overview.md
- product-plan/instructions/incremental/05-vector-shell.md
- product-plan/sections/vector-shell/README.md
- product-plan/sections/vector-shell/types.ts
- product-plan/sections/vector-shell/tests.md
- product-plan/sections/vector-shell/components/ (all files)

## TDD Workflow

1. Write tests for dock interactions and overlay system
2. Adapt VectorShell and UtilityDock components
3. Create shellStore.ts for global state
4. Connect to existing audio/visual stores

## Questions to Ask Me

1. Should overlays render the actual section components, or placeholders?
2. How should keyboard hotkeys (1-5) be handled?
3. Should settings persist across sessions?
```

---

## Pro Tips

### 1. Always Provide Context
Start each session by asking the AI to read `product-overview.md` — it contains the full product context.

### 2. Enforce TDD
If the AI starts implementing without tests, say:
> "Wait - let's follow TDD. Please write the tests first based on tests.md, then implement the code."

### 3. Use Sample Data
Tell the AI:
> "Use the sample-data.json file for testing before we implement real data fetching."

### 4. Keep Components Props-Based
If the AI adds internal data fetching to components, say:
> "Components should be props-based. Move data fetching to the parent or a store."

### 5. Commit After Each Milestone
After each milestone passes tests:
```bash
git add .
git commit -m "feat: implement [section-name] section"
```

---

## Quick Reference: File Locations

| Milestone | Key Files |
|-----------|-----------|
| Foundation | `instructions/incremental/01-foundation.md`, `design-system/`, `shell/` |
| Audio Core | `sections/audio-core/README.md`, `tests.md`, `components/` |
| Visual Engine | `sections/visual-engine/README.md`, `tests.md`, `components/` |
| Neural Link | `sections/neural-link/README.md`, `tests.md`, `components/` |
| Vector Shell | `sections/vector-shell/README.md`, `tests.md`, `components/` |

---

## Example: Full First Message

Here's a complete example of your very first message to start the project:

```
I'm building VectorHive, a Svelte 5 music visualization app. I have a complete design handoff package with component code, types, and test instructions.

## Important Files (in product-plan/ folder)

- product-overview.md — Complete product context
- instructions/incremental/ — Step-by-step milestones
- sections/ — Each section has README, tests.md, types, and Svelte components
- design-system/ — Colors, fonts, CSS tokens

## Approach

We'll use TDD + Incremental:
1. Read the milestone instructions
2. Write tests first (from tests.md)
3. Adapt the provided Svelte 5 components
4. Wire up stores and callbacks
5. Verify tests pass

## Let's Start with Milestone 1: Foundation

Please read:
- product-plan/product-overview.md
- product-plan/instructions/incremental/01-foundation.md

Then ask me any clarifying questions before we begin.
```

---

That's it! Follow this pattern for each milestone, and you'll have a complete, well-tested VectorHive implementation.
