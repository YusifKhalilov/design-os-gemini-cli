# VectorHive - Product Handoff Package

A personal, high-intensity music visualization tool that generates immersive geometric patterns fueled by music.

## What's Included

| Directory | Contents |
|-----------|----------|
| `product-overview.md` | Complete product summary, sections, and implementation sequence |
| `prompts/` | Ready-to-use prompts for your coding agent |
| `instructions/` | Step-by-step implementation instructions (one-shot & incremental) |
| `design-system/` | Color tokens, typography, CSS custom properties |
| `data-model/` | Entity types and sample data |
| `shell/` | Application shell components |
| `sections/` | 4 section component packages with test instructions |

## How to Use

### Recommended: Incremental + TDD Approach

1. **Copy this folder** to your implementation codebase
2. **Start with `instructions/incremental/01-foundation.md`** — Set up project, tokens, routing
3. **For each milestone**, open the corresponding instruction file
4. **Write tests first** using `sections/[section-id]/tests.md`
5. **Copy component code** from `sections/[section-id]/components/`
6. **Wire up callbacks** and data fetching as specified

### Alternative: One-Shot Approach

1. Open `prompts/one-shot-prompt.md`
2. Fill in any additional notes
3. Paste entire prompt into your coding agent
4. Answer the agent's clarifying questions

## TDD Workflow

For each section:

1. **Read the spec** → `sections/[section-id]/README.md`
2. **Write tests** → Use `sections/[section-id]/tests.md` as a guide
3. **Copy components** → Adapt from `sections/[section-id]/components/`
4. **Wire up logic** → Implement callbacks, state management, data fetching
5. **Verify tests pass** → All user flows should work

## Tech Stack

This export is prepared for:

- **Framework:** Svelte 5 (Runes mode)
- **Styling:** Tailwind CSS + CSS Custom Properties
- **Build Tool:** Vite
- **Strategy:** TDD-focused, Incremental

## Tips for Best Results

- **Always provide `product-overview.md`** with each implementation session
- **Components are props-based** — they accept data and callbacks
- **Sample data is for testing** — use before real APIs are ready
- **Screenshots provide visual reference** — check fidelity
- **The export is self-contained** — no dependencies on Design OS

## Implementation Milestones

1. **Foundation** — Project setup, design tokens, routing, shell
2. **Audio Core** — Audio input sources and real-time feature extraction
3. **Visual Engine** — Fullscreen generative visuals with feedback loop
4. **Neural Link** — TensorFlow.js model training interface
5. **Vector Shell** — HUD overlay and utility dock

---

Generated: 2026-01-05
Framework: Svelte 5
Strategy: Incremental + TDD
