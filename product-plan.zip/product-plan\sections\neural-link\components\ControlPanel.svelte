<script lang="ts">
  import type { ModelConfig } from '../types';

  interface Props {
    config: ModelConfig | undefined;
    onUpdate: (updates: Partial<ModelConfig>) => void;
    readOnly?: boolean;
  }

  let { config, onUpdate, readOnly = false }: Props = $props();
</script>

{#if !config}
  <div class="p-6 text-zinc-500 font-mono text-sm">No Configuration Selected</div>
{:else}
  <div class="bg-zinc-900/40 backdrop-blur-sm border border-zinc-800 rounded-xl p-5 space-y-6">
    <div class="grid grid-cols-2 items-center border-b border-zinc-800 pb-3">
      <h3 class="text-zinc-100 font-medium text-sm tracking-wide">HYPERPARAMETERS</h3>
      <span class="text-[10px] text-primary-500 font-mono bg-primary-500/10 px-2 py-0.5 rounded border border-primary-500/20 text-right justify-self-end">
        {config.architecture.toUpperCase()}
      </span>
    </div>

    <div class="space-y-5">
      <!-- Learning Rate Slider -->
      <div class="space-y-2">
        <div class="grid grid-cols-2 text-xs font-mono">
          <label class="text-zinc-400">Learning Rate</label>
          <span class="text-primary-400 text-right">{config.learningRate}</span>
        </div>
        <input
          type="range"
          min="0.0001"
          max="0.01"
          step="0.0001"
          disabled={readOnly}
          value={config.learningRate}
          oninput={(e) => onUpdate({ learningRate: parseFloat((e.target as HTMLInputElement).value) })}
          class="w-full h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-primary-500 hover:accent-primary-400 touch-none"
          aria-label="Learning Rate"
        />
      </div>

      <!-- Batch Size Selection -->
      <div class="space-y-2">
        <div class="grid grid-cols-2 text-xs font-mono">
          <label class="text-zinc-400">Batch Size</label>
          <span class="text-primary-400 text-right">{config.batchSize}</span>
        </div>
        <div class="grid grid-cols-4 gap-2">
          {#each [16, 32, 64, 128] as size}
            <button
              disabled={readOnly}
              onclick={() => onUpdate({ batchSize: size })}
              class="text-[10px] font-mono py-1.5 rounded border transition-all"
              class:bg-primary-500={config.batchSize === size}
              class:text-white={config.batchSize === size}
              class:border-primary-500={config.batchSize === size}
              class:shadow-[0_0_10px_rgba(16,185,129,0.3)]={config.batchSize === size}
              class:bg-zinc-900={config.batchSize !== size}
              class:text-zinc-500={config.batchSize !== size}
              class:border-zinc-800={config.batchSize !== size}
              class:hover:border-zinc-700={config.batchSize !== size}
            >
              {size}
            </button>
          {/each}
        </div>
      </div>

      <!-- Epochs Input -->
      <div class="space-y-2">
        <label class="text-xs font-mono text-zinc-400">Target Epochs</label>
        <div class="relative">
          <input
            type="number"
            disabled={readOnly}
            value={config.epochs}
            oninput={(e) => onUpdate({ epochs: parseInt((e.target as HTMLInputElement).value) })}
            class="w-full bg-zinc-950 border border-zinc-800 text-zinc-300 text-xs font-mono p-2 rounded focus:outline-none focus:border-primary-500/50 transition-colors"
          />
          <div class="absolute right-2 top-2 text-[10px] text-zinc-600 font-mono pointer-events-none">ITERATIONS</div>
        </div>
      </div>

      <!-- Optimizer Toggle -->
      <div class="space-y-2">
        <label class="text-xs font-mono text-zinc-400">Optimizer</label>
        <div class="grid grid-cols-3 bg-zinc-950 p-1 rounded-lg border border-zinc-800">
          {#each ['adam', 'sgd', 'rmsprop'] as opt}
            <button
              disabled={readOnly}
              onclick={() => onUpdate({ optimizer: opt as 'adam' | 'sgd' | 'rmsprop' })}
              class="text-[10px] uppercase font-bold py-1.5 rounded-md transition-all"
              class:bg-zinc-800={config.optimizer === opt}
              class:text-zinc-100={config.optimizer === opt}
              class:shadow-sm={config.optimizer === opt}
              class:text-zinc-600={config.optimizer !== opt}
              class:hover:text-zinc-400={config.optimizer !== opt}
            >
              {opt}
            </button>
          {/each}
        </div>
      </div>
    </div>

    {#if !readOnly}
      <div class="pt-2 text-[10px] text-zinc-500 leading-relaxed italic border-t border-zinc-800/50">
        Adjusting parameters during an active session may cause instability.
      </div>
    {/if}
  </div>
{/if}
