# Milestone 05: Vector Shell

## Overview
HUD overlay container with utility dock and configuration overlays.

---

## Key Functionality
1. Persistent floating utility dock at bottom
2. Transport controls (Play/Pause/Reset)
3. Module buttons (Audio/Visual/Neural overlays)
4. Preset quick-switcher (1-5 hotkeys)
5. System settings (Performance mode, etc.)
6. Full-screen configuration overlays

## Files to Reference
- `product-plan/sections/vector-shell/README.md`
- `product-plan/sections/vector-shell/types.ts`
- `product-plan/sections/vector-shell/components/`
- `product-plan/sections/vector-shell/tests.md`

## Component Props

### VectorShell

| Prop | Type | Description |
|------|------|-------------|
| `shellState` | `ShellState` | Playback and overlay state |
| `settings` | `SystemSettings` | Global settings |
| `presets` | `ScenePreset[]` | Available scene presets |
| `onTogglePlayback` | `() => void` | Play/Pause |
| `onOpenOverlay` | `(overlay) => void` | Open module config |
| `onApplyPreset` | `(presetId) => void` | Switch preset |
| `onUpdateSettings` | `(key, value) => void` | Update setting |

## Store Implementation

```typescript
// shellStore.ts
import { writable } from 'svelte/store';

export const shellStore = writable({
  isPlaying: false,
  activeOverlay: null,
  currentPresetId: 'preset-neon-pulse'
});

export const settingsStore = writable({
  themeMode: 'dark',
  performanceMode: 'high-performance',
  audioDeviceId: 'default',
  showFps: true
});
```

## Done Criteria
- [ ] Dock displays at bottom center
- [ ] All dock buttons work
- [ ] Overlays open and close
- [ ] Presets switch correctly
- [ ] Settings persist to localStorage
- [ ] All tests pass

## Final Step
Run full integration tests across all sections.
