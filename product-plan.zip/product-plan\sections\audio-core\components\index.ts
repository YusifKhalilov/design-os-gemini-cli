export { default as AudioCore } from './AudioCore.svelte';
